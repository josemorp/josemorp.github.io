package cat.proven.mvc.views;

/**
 * Menu class for MVC app
 * @author Jose
 */
public class MvcMenu extends Menu {

    public MvcMenu() {
        title = "MVC example main menu";
        addOption(new Option("Exit application", "exit"));
        addOption(new Option("Greet with name", "greet"));
    }
    
}

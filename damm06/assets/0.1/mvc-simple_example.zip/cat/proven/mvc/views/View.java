package cat.proven.mvc.views;

import cat.proven.mvc.controllers.Controller;
import cat.proven.mvc.model.Model;
import java.util.Scanner;

/**
 * View for MVC
 * @author Jose
 */
public class View {
    
    private Model model;
    private Controller controller;
    
    private MvcMenu menu;
    
    /**
     * flag to exit application
     */
    private boolean exit;
    
    /**
     * object to read from standard input
     */
    private Scanner input;

    public View(Controller controller, Model model) {
        this.model = model;
        this.controller = controller;
        this.menu = new MvcMenu();
        this.input = new Scanner(System.in);
    }
    
    public void show() {
        exit = false;
        do {
            menu.show();
            String action = menu.getSelectedOptionActionCommand();
//            switch (action) {
//                case "exit":
//                    
//                    break;
//                case "greet":
//                    
//                    break;
//                default:
//                    throw new AssertionError();
//            }
            //controller processes actions
            controller.processAction(action);
        } while (!exit);
    }
    
    /**
     * displays a message to user
     * @param message the message to display
     */
    public void showMessage(String message) {
        System.out.println(message);
    }
    
    /**
     * promps a message and gets an answer from user
     * @param message the message to display
     * @return user's answer
     */
    public String inputString(String message) {
        System.out.print(message);
        return input.next();
    }

    /**
     * close view
     */
    public void close() {
        exit = true;
    }
    
}

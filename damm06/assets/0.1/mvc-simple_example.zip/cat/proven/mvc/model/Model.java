package cat.proven.mvc.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Model for MVC
 * @author Jose
 */
public class Model {
   
    /**
     * data to query from controller
     */
    private final List<String> people;

    public Model() {
        people = new ArrayList<>();
        //initialize test data
        fetchPeople();
    }

    /**
     * finds a name in list
     * @param name the name to search
     * @return name found or null if not found
     */
    public String findByName(String name) {
        String found = null;
        int index = people.indexOf(name);
        if (index >= 0) {
            found = people.get(index);
        }
        return found;
    }
    
    /**
     * simulates fetching data from persistence data source
     */
    public void fetchPeople() {
        people.add("Peter");
        people.add("Mary");
        people.add("Louis");
        people.add("Sandra");
    }
}

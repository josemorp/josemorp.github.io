package cat.proven.mvc.controllers;

import cat.proven.mvc.model.Model;
import cat.proven.mvc.views.View;

/**
 * Controller for MVC
 * @author Jose
 */
public class Controller {

    private Model model;
    private View view;

    public Controller(Model model) {
        this.model = model;
        this.view = new View(this, model);
    }

    /**
     * starts controller work
     */
    public void start() {
        view.show();
    }
    
    /**
     * executes responses to actions
     * @param action the action to process
     */
    public void processAction(String action) {
        switch (action) {
            case "exit": //exit application
                doExit();
                break;
            case "greet":  //greet
                doGreet();
                break;
            default:  //assertion error if unknown action
                throw new AssertionError("Unknown action to process: "+action);
        }
    }

    /**
     * exits application
     */
    private void doExit() {
        String answer = view.inputString("Are you sure? (Y/N)");
        if (answer.toLowerCase().charAt(0) == 'y') {
            view.close();
        }
    }

    /**
     * gets name from model and displays greeting
     */
    private void doGreet() {
        String nameToSearch = view.inputString("Name: ");
        String name = model.findByName(nameToSearch);
        if (name != null) {
            view.showMessage("Hello "+name);
        } else {
            view.showMessage("Name '"+ nameToSearch + "' not found");
        }
    }

}

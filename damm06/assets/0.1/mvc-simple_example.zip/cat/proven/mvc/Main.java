package cat.proven.mvc;

import cat.proven.mvc.controllers.Controller;
import cat.proven.mvc.model.Model;

/**
 * Example of MVC with fake data
 * @author Jose
 */
public class Main {

    public static void main(String[] args) {
        //instantiate model (data service)
        Model model = new Model();
        //instantiate controller and pass model to it
        Controller controller = new Controller(model);
        //initiate controller work
        controller.start();
        //report end of application
        System.out.println("Application finished");
    }
    
}

package cat.proven.utils.reflect;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Reflection example to generate generic object form.
 * @author Jose
 */
public class ReflectForm {

    /**
     * Converts object to a String representation using reflection.
     * @param obj to convert to String.
     * @return string representation of object.
     */
    public String objToString(Object obj) {
        Class c = obj.getClass();
        StringBuilder sb = new StringBuilder();
        String className = c.getName();
        sb.append(className).append("{");
        Field[] fields = c.getDeclaredFields();
        for (Field f : fields) {
            String fieldName = f.getName();
            f.setAccessible(true);
            Object fieldValue = null;
            try {
                fieldValue = f.get(obj);
            } catch (IllegalArgumentException | IllegalAccessException ex) {
                Logger.getLogger(ReflectForm.class.getName()).log(Level.SEVERE, null, ex);
            }
            f.setAccessible(false);
            sb.append(String.format("[%s=%s]", fieldName, fieldValue));
        }
        sb.append("}");
        return sb.toString();
    }

    /**
     * reads a string from standard input,
     * @return the read string.
     */
    public String readString() {
        Scanner sc = new Scanner(System.in);
        String s = sc.next();
        return s;
    }

    /**
     * Reads all properties of an object using reflection.
     * @param obj initial state of object.
     * @return a nes object of the same type of the parameter, with the new values.
     */
    public Object readObject(Object obj)  {
        Class c = obj.getClass();
        Object result = null;
        try {
            Field[] fields = c.getDeclaredFields();
            Constructor<?> cons = c.getConstructor(new Class<?>[]{c});
            result = cons.newInstance(new Object[]{obj});
            for (Field f : fields) {
                String fieldName = f.getName();
                System.out.format("%s: ", fieldName);
                String sValue = readString();
                f.setAccessible(true);
                Object fieldValue = castDynamicClass(f.getType(), sValue);
                f.set(result, fieldValue);
                f.setAccessible(false);
            }
        } catch (InstantiationException | IllegalArgumentException | IllegalAccessException | NoSuchMethodException | InvocationTargetException ex) {
                Logger.getLogger(ReflectForm.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }    
    
    /**
     * Dynamic cast of a string to another class.
     * @param dynamicClass the class to convert to.
     * @param value the value to be converted, in string format.
     * @return object of the given class with the given value.
     */
    public Object castDynamicClass(Class dynamicClass, String value) {
        Object object = null;
        try {
            Constructor<?> cons
                    = dynamicClass.getConstructor(new Class<?>[]{String.class});
            object = cons.newInstance(value);                
        } catch (NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
            Logger.getLogger(ReflectForm.class.getName()).log(Level.SEVERE, null, ex);
        }
        return object;
    }
}

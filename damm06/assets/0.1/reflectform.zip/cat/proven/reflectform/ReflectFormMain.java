package cat.proven.reflectform;

import cat.proven.reflectform.model.Model;
import cat.proven.reflectform.model.Product;
import cat.proven.reflectform.model.Customer;
import cat.proven.utils.reflect.ReflectForm;

/**
 * Example of reflection use to generate generic input for any object.
 * @author Jose
 */
public class ReflectFormMain {

    public static void main(String[] args) {
        Model model = new Model();
        model.setCustomer(new Customer(1L, "Peter", "123"));
        model.setProduct(new Product(1L, "Tv1", 101.0, 11));
        
        Customer c = model.getCustomer();
        Product p = model.getProduct();
        
        ReflectForm reflectUtil = new ReflectForm();
        System.out.println(reflectUtil.objToString(p));
        System.out.println(reflectUtil.objToString(c));
        
        Object p1 = reflectUtil.readObject(p);
        Object c1 = reflectUtil.readObject(c);
        
        System.out.println("c="+c.toString());
        System.out.println("p="+p.toString());
        
        System.out.println("p1="+p1.toString());
        System.out.println("c1="+c1.toString());
    }
    
}

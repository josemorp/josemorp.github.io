package cat.proven.reflectform.model;

/**
 *
 * @author Jose
 */
public class Product {
    private Long id;
    private String code;
    private Double price;
    private Integer stock;

    public Product(long id, String code, double price, int stock) {
        this.id = id;
        this.code = code;
        this.price = price;
        this.stock = stock;
    }

    public Product(long id) {
        this.id = id;
    }

    public Product(Product other) {
        this.id = other.id;
        this.code = other.code;
        this.price = other.price;
        this.stock = other.stock;
    }
    
    public Product() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + (int) (this.id ^ (this.id >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Product other = (Product) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Product{" + "id=" + id + ", code=" + code + ", price=" + price + ", stock=" + stock + '}';
    }
    
}

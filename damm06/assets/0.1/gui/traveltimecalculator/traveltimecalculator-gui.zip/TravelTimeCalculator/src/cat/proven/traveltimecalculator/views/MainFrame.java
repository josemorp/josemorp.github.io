package cat.proven.traveltimecalculator.views;

import cat.proven.traveltimecalculator.controllers.ViewController;
import java.awt.Container;
import java.awt.FlowLayout;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

/**
 * Main frame for travel time calculator.
 *
 * @author Jose
 */
public class MainFrame extends JFrame {

    private final ViewController controller;
    //
    private WelcomePanel welcomePanel;
    private ConfigPanel configPanel;
    private CalcPanel calcPanel;
    private JMenuBar menuBar;
    private final String aboutMessage;

    public MainFrame(ViewController controller) {
        this.controller = controller;
        initComponents();
        aboutMessage = String.format(
                "<html><p><strong>%s</strong></p><p>(c)ProvenSoft</p></html>",
                getTitle());
    }

    public ConfigPanel getConfigPanel() {
        return configPanel;
    }

    public CalcPanel getCalcPanel() {
        return calcPanel;
    }

    private void initComponents() {
        setTitle("Travel time calculator");
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(controller);
        menuBar = buildJMenuBar();
        setJMenuBar(menuBar);
        Container pane = getContentPane();
        pane.setLayout(new FlowLayout());
        pane.add(new WelcomePanel());
        setLocationRelativeTo(null);
        setSize(600, 400);
    }

    private JMenuBar buildJMenuBar() {
        JMenu mnu;
        JMenuItem mItem;
        JMenuBar mBar = new JMenuBar();
        mnu = new JMenu("File");
        mItem = new JMenuItem("Exit");
        mItem.setActionCommand("exit");
        mItem.addActionListener(controller);
        mnu.add(mItem);
        mBar.add(mnu);
        mnu = new JMenu("Calc");
        mItem = new JMenuItem("Configuration panel");
        mItem.setActionCommand("confpanel");
        mItem.addActionListener(controller);
        mnu.add(mItem);
        mItem = new JMenuItem("Calculation form");
        mItem.setActionCommand("calcform");
        mItem.addActionListener(controller);
        mnu.add(mItem);
        mBar.add(mnu);
        mnu = new JMenu("Help");
        mItem = new JMenuItem("About");
        mItem.setActionCommand("about");
        mItem.addActionListener(controller);
        mnu.add(mItem);
        mBar.add(mnu);
        return mBar;
    }

    public void displayMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

    public boolean confirm(String message) {
        int answer = JOptionPane.showConfirmDialog(this, message);
        return (answer == JOptionPane.OK_OPTION);
    }

    public void showAboutDialog() {
        JOptionPane.showMessageDialog(this, aboutMessage);
    }

    public void showConfPanel() {
        Container pane = getContentPane();
        pane.removeAll();
        repaint();
        configPanel = new ConfigPanel(controller);
        pane.setLayout(new FlowLayout());
        pane.add(configPanel);
        this.validate();
    }

    public void showCalcPanel() {
        Container pane = getContentPane();
        pane.removeAll();
        repaint();
        calcPanel = new CalcPanel(controller);
        pane.setLayout(new FlowLayout());
        pane.add(calcPanel);
        this.validate();
    }

}

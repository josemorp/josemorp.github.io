package cat.proven.traveltimecalculator.views;

import cat.proven.traveltimecalculator.controllers.ViewController;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EtchedBorder;
import javax.swing.border.MatteBorder;

/**
 * Configuration panel of travel time calculator application.
 * Allows setting speed limits of every road type.
 * @author Jose
 */
public class ConfigPanel extends JPanel {
    
    private final ViewController controller;
    private JComboBox<String> cbRoads;
    private JFormattedTextField tfSpeedLimit;
    
    public ConfigPanel(ViewController controller) {
        this.controller = controller;
        initComponents();
    }
    
    private void initComponents() {
        setBorder(new EtchedBorder());
        setLayout(new GridLayout(0,1));
        //row 1.
        JLabel label = new JLabel();
        label.setText("Configuration panel");
        add(label);
        //row 2.
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(1,2));
        
        cbRoads = new JComboBox<>(controller.getModel().getRoadTypes());
        cbRoads.addItemListener((e) -> {
            tfSpeedLimit.setValue(
                controller.getModel().getSpeedLimit(
                    (String) cbRoads.getSelectedItem()
                ));
        });
        panel.add(cbRoads);
        //
        tfSpeedLimit = new JFormattedTextField(0.0);
        panel.add(tfSpeedLimit);
        //
        add(panel);
        //row 3.
        JButton btSetSpeed = new JButton("Change");
        btSetSpeed.setActionCommand("set_speed");
        btSetSpeed.addActionListener(controller);
        add(btSetSpeed); add(new JLabel());
        //initialize text field.
        tfSpeedLimit.setValue(
                controller.getModel().getSpeedLimit(
                    (String) cbRoads.getSelectedItem()
                ));
        
    }
    
    public String getRoadTypeValue() {
        return (String) cbRoads.getSelectedItem();
    }
    
    public double getSpeedLimitValue() {
        return (double) tfSpeedLimit.getValue();
    }
    
    public void setSpeedLimitValue(double value) {
        tfSpeedLimit.setValue(value);
    }
    
}

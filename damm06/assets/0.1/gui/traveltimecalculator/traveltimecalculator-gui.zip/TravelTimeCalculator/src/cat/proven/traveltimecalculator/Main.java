package cat.proven.traveltimecalculator;

import cat.proven.traveltimecalculator.controllers.ViewController;
import cat.proven.traveltimecalculator.model.TravelTimeCalculator;
import cat.proven.traveltimecalculator.views.MainFrame;

/**
 * Main class for travel time calculator application.
 * This class is the entry point to the application.
 * @author Jose
 */
public class Main {

    public static void main(String[] args) {
        //instantiate model.
        TravelTimeCalculator ttcalc = new TravelTimeCalculator();
        //instantiate controller.
        ViewController controller = new ViewController(ttcalc);
        javax.swing.SwingUtilities.invokeLater(() -> {
            //instantiate main view.
            MainFrame frame = new MainFrame(controller);
            //assign view to controller.
            controller.setFrame(frame);
            //make view visible.
            frame.setVisible(true);
        });
    }
    
}

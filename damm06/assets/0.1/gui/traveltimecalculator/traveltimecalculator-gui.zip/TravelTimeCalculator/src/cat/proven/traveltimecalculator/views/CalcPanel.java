package cat.proven.traveltimecalculator.views;

import cat.proven.traveltimecalculator.controllers.ViewController;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EtchedBorder;

/**
 *
 * @author Jose
 */
public class CalcPanel extends JPanel {

    private final ViewController controller;
    private JComboBox<String> cbRoads;
    private JFormattedTextField tfSpeedLimit;
    private JFormattedTextField tfDistance;
    private JFormattedTextField tfEstimatedTime;
    
    public CalcPanel(ViewController controller) {
        this.controller = controller;
        initComponents();
    }

    private void initComponents() {
        setBorder(new EtchedBorder());
        setLayout(new GridLayout(0,2));
        
        add(new JLabel("Calculation panel")); add(new JLabel());

        cbRoads = new JComboBox<>(controller.getModel().getRoadTypes());
        cbRoads.addItemListener((e) -> {
            tfSpeedLimit.setValue(
                controller.getModel().getSpeedLimit(
                    (String) cbRoads.getSelectedItem()
                ));
                setEstimatedTimeValue(0.0);
        });
        add(cbRoads);
        
        tfSpeedLimit = new JFormattedTextField(0.0);
        tfSpeedLimit.setEditable(false);
        add(tfSpeedLimit);

        add(new JLabel("Distance (km): "));
        tfDistance = new JFormattedTextField(0.0);;
        add(tfDistance);        
        
        JButton btSetSpeed = new JButton("Calculate time");
        btSetSpeed.setActionCommand("calc_time");
        btSetSpeed.addActionListener(controller);
        add(new JLabel()); add(btSetSpeed);
        
        add(new JLabel("Estimated time (h): "));
        tfEstimatedTime = new JFormattedTextField(0.0);
        tfEstimatedTime.setEditable(false);
        add(tfEstimatedTime);
        
        tfSpeedLimit.setValue(
                controller.getModel().getSpeedLimit(
                    (String) cbRoads.getSelectedItem()
                ));       
    }
    
    public String getRoadTypeValue() {
        return (String) cbRoads.getSelectedItem();
    }
    
    public double getDistanceValue() {
        return (double) tfDistance.getValue();
    }
    
    public void setEstimatedTimeValue(double value) {
        tfEstimatedTime.setValue(value);
    }
    
}

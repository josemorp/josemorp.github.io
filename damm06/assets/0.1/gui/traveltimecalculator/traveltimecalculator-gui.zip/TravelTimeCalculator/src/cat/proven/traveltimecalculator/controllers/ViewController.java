package cat.proven.traveltimecalculator.controllers;

import cat.proven.traveltimecalculator.model.TravelTimeCalculator;
import cat.proven.traveltimecalculator.views.MainFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.JOptionPane;

/**
 *
 * @author Jose
 */
public class ViewController implements ActionListener, WindowListener {

    /**
     * the model to manage data.
     */
    private TravelTimeCalculator model;
    /**
     * the main view.
     */
    private MainFrame frame;

    public ViewController(TravelTimeCalculator model) {
        this.model = model;
    }

    public TravelTimeCalculator getModel() {
        return model;
    }

    public void setModel(TravelTimeCalculator model) {
        this.model = model;
    }

    public MainFrame getFrame() {
        return frame;
    }

    public void setFrame(MainFrame frame) {
        this.frame = frame;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String action = e.getActionCommand();
        if (action != null) {
            switch (action) {
                case "exit":
                    handleExitApplication();
                    break;
                case "about":
                    frame.showAboutDialog();
                    break;
                case "confpanel":
                    frame.showConfPanel();
                    break;
                case "calcform":
                    frame.showCalcPanel();
                    break;
                case "set_speed":
                    handleSetSpeedLimit();
                    break;
                case "calc_time":
                    handleCalcTime();
                    break;
                default:
                    frame.displayMessage(String.format("Action %s", action));
                    break;
            }
        }
    } 

    /* handlers of window events */
    
    @Override
    public void windowClosing(WindowEvent e) {
        handleExitApplication();
    }
    
    @Override
    public void windowOpened(WindowEvent e) {}
    
    @Override
    public void windowClosed(WindowEvent e) {}

    @Override
    public void windowIconified(WindowEvent e) {}

    @Override
    public void windowDeiconified(WindowEvent e) {}

    @Override
    public void windowActivated(WindowEvent e) {}

    @Override
    public void windowDeactivated(WindowEvent e) {}    
    
    /**
     * handle method to exit application.
     */
    public void handleExitApplication() {
        if (frame.confirm("Exit application. Are you sure")) {
            System.exit(0);
        }
    }

    /**
     * handle method to set speed limit.
    */
    private void handleSetSpeedLimit() {
        String roadType = getFrame().getConfigPanel().getRoadTypeValue();
        double speed = getFrame().getConfigPanel().getSpeedLimitValue();
        boolean result = model.setSpeedLimit(roadType, speed);
        if (result) {
            JOptionPane.showMessageDialog(frame, "Successfully changed");
        } else {
            JOptionPane.showMessageDialog(frame, "Speed not changed");
        }
    }
    
    /**
     * handle method to calculate estimated time.
    */
    private void handleCalcTime() {
        double distance = getFrame().getCalcPanel().getDistanceValue();
        String roadType = getFrame().getCalcPanel().getRoadTypeValue();
        double estimatedTime = model.calculateTime(distance, roadType);
        getFrame().getCalcPanel().setEstimatedTimeValue(estimatedTime);
    }


}

package cat.proven.traveltimecalculator.views;

import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * Welcome panel of travel time calculator application.
 * @author Jose
 */
public class WelcomePanel extends JPanel {

    private final String welcomeMsg;
    
    public WelcomePanel() {
        welcomeMsg = 
                "<html><p>Welcome to travel time calculator!</p><p>(c) JoseSoft</p></html>";
        initComponents();
    }

    private void initComponents() {
        JLabel label = new JLabel();
        label.setText(welcomeMsg);
        add(label);
    }
    
}

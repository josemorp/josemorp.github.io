package cat.proven.texteditor;


import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * Main frame for text editor example
 * @author Jose
 */
public class TextEditorFrame extends JFrame {

    private final String frameTitle;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new TextEditorFrame().setVisible(true);
        });
    }
    
    public TextEditorFrame() {
        frameTitle = "Text editor";
        initComponents();
    }

    private void initComponents() {
           UIManager.put("swing.boldMetal", Boolean.FALSE);
           setTitle(frameTitle);
           setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
           Container contentPane = getContentPane();
           add(new TextEditorPanel());
           pack();
    }

}

package cat.proven.currencyconverter.views;

import cat.proven.currencyconverter.controller.CurrencyConverterController;
import cat.proven.currencyconverter.model.CurrencyConverter;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

/**
 *
 * @author Jose
 */
public class MainFrame extends JFrame implements ActionListener {

    private final CurrencyConverter model;
    private final CurrencyConverterController controller;
    
    private String titleText;
    private JMenuBar menuBar;
    private String aboutText;
    
    private ConvertPanel convertPanel;
    private RatePanel ratePanel;
    private JMenuItem clearItem;
    private final ActionListener listener;
    
    public MainFrame(CurrencyConverterController controller, 
                    CurrencyConverter model) {
        this.controller = controller;
        this.model = model;
        this.listener = this;
        initComponents();
    }

    public CurrencyConverter getModel() {
        return model;
    }
    
    public ConvertPanel getConvertPanel() {
        return convertPanel;
    }

    public RatePanel getRatePanel() {
        return ratePanel;
    }
    
    private void initComponents() {
        titleText = "Currency converter";
        aboutText = "<html><p>Currency converter</p> <p><i>(c) ProvenSoft</i></p></html>";
        setTitle(titleText);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                exitApp();
            }
        });
        buildMenuBar();
        Container contentPane = getContentPane();
        contentPane.add( new WelcomePanel() );
        setSize(400, 300);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    /**
     * builds the menu bar.
     */
    private void buildMenuBar() {
        menuBar = new JMenuBar();
        JMenu mnu;
        JMenuItem mnuItem;
        
        //file menu
        mnu = new JMenu("File");
            mnuItem = new JMenuItem("Exit");
            mnuItem.setActionCommand("exit");
            mnuItem.addActionListener(listener);
            mnu.add(mnuItem);
        menuBar.add(mnu);

        //edit menu
        mnu = new JMenu("Edit");
            mnuItem = new JMenuItem("Rate form");
            mnuItem.setActionCommand("rate-form");
            mnuItem.addActionListener(listener);
            mnu.add(mnuItem);
            mnuItem = new JMenuItem("Convert form");
            mnuItem.setActionCommand("convert-form");
            mnuItem.addActionListener(listener);
            mnu.add(mnuItem);
            mnuItem = new JMenuItem("Clear");
            mnuItem.setActionCommand("clear");
            mnuItem.addActionListener(listener);
            mnuItem.setEnabled(false);
            clearItem = mnuItem;
            mnu.add(mnuItem);
        menuBar.add(mnu);        

        //edit menu
        mnu = new JMenu("Help");
            mnuItem = new JMenuItem("About");
            mnuItem.setActionCommand("about");
            mnuItem.addActionListener(listener);
            mnu.add(mnuItem);
        menuBar.add(mnu);  
        
        setJMenuBar(menuBar);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String action = e.getActionCommand();
//        System.out.println("Action: "+action);
        if (action != null) {
            switch (action) {
                case "convert-form":
                    displayConvertForm();
                    break;
                case "about":
                    displayAbout();
                    break;
                case "clear":
                    clearConvertForm();
                    break;
                case "rate-form":
                    displayRateForm();
                    break;
                default:
                    controller.processRequest(action);
                    break;
            }            
        }
    }

    public void exitApp() {
        int result = JOptionPane.showConfirmDialog(this, "Are you sure?");
        if (result == JOptionPane.OK_OPTION) {
            System.exit(0);
        }  
    }

    private void displayAbout() {
        JOptionPane.showMessageDialog(this, aboutText);
    }

    private void displayConvertForm() {
        convertPanel = new ConvertPanel(listener);
        //setContentPane(convertPanel);
        getContentPane().removeAll();
        add(convertPanel);
        validate();
        //enable clear menu item.
        clearItem.setEnabled(true);
    }

    private void clearConvertForm() {
        convertPanel.clearForm();
    }

    private void displayRateForm() {
        ratePanel = new RatePanel(listener);
        ratePanel.setRate(model.getRatioDE());
        //setContentPane(ratePanel);
        getContentPane().removeAll();
        add(ratePanel);
        validate();
        clearItem.setEnabled(false);
    }
    
}

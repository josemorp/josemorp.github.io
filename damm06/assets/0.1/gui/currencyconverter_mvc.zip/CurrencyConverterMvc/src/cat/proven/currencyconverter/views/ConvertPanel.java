package cat.proven.currencyconverter.views;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Jose
 */
public class ConvertPanel extends JPanel {

    private JFormattedTextField tfDollars;
    private JFormattedTextField tfEuros;
    private final ActionListener listener;
    
    public ConvertPanel(ActionListener listener) {
        this.listener = listener;
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());
        //header
        JLabel lbHeader = new JLabel("Conversion panel");
        lbHeader.setHorizontalAlignment(JLabel.CENTER);
        lbHeader.setForeground(Color.RED);
        add(lbHeader, BorderLayout.NORTH);
        //form
        JPanel form = new JPanel();
        form.setLayout(new GridLayout(3,2));
        //1st row
        form.add(new JLabel("dollars: "));
        //set the formatter for double fields.
        NumberFormat format = NumberFormat.getNumberInstance();
        format.setMinimumFractionDigits(2);
        format.setMaximumFractionDigits(2);
        //
        tfDollars = new JFormattedTextField(format);
        form.add(tfDollars);
        //2nd row
        JButton btDE = new JButton("Dollar to euro");
        btDE.setActionCommand("convert-dollar-euro");
        btDE.addActionListener(listener);
        form.add(btDE);
        JButton btED = new JButton("Euro to dollar");
        btED.setActionCommand("convert-euro-dollar");
        btED.addActionListener(listener);
        form.add(btED);
        //3rd row        
        form.add(new JLabel("euros: "));
        tfEuros = new JFormattedTextField(format);
        form.add(tfEuros);
        //
        add(form, BorderLayout.CENTER);
        clearForm();
    }

    public double getEuroValue() {
//        String valueTxt = tfEuros.getText();
//        double value = 0.0;
//        try {
//            value = Double.parseDouble(valueTxt);
//        } catch (NumberFormatException e) {
//            value = 0.0;
//            tfEuros.setText("Error");
//        }
        double value = ((Number)tfEuros.getValue()).doubleValue();
        return value;
    }

    public void setDollarValue(double value) {
        //tfDollars.setText(String.valueOf(value));
        tfDollars.setValue(value);
    }

    public double getDollarValue() {
//        String valueTxt = tfDollars.getText();
//        double value = 0.0;
//        try {
//            value = Double.parseDouble(valueTxt);
//        } catch (NumberFormatException e) {
//            value = 0.0;
//            tfDollars.setText("Error");
//        }
        double value = ((Number)tfDollars.getValue()).doubleValue();
        return value;
    }

    public void setEuroValue(double value) {
        //tfEuros.setText(String.valueOf(value));
        tfEuros.setValue(value);
    }    

    public void clearForm() {
        //tfEuros.setText("0.0");
        //tfDollars.setText("0.0");
        tfEuros.setValue(0.0);
        tfDollars.setValue(0.0);
    }
     
}

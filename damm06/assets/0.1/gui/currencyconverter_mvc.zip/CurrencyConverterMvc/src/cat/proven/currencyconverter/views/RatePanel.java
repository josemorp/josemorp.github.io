package cat.proven.currencyconverter.views;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
/**
 * 
 * @author Jose
 */
public class RatePanel extends JPanel {

    private JFormattedTextField tfRate;
    private final ActionListener listener;
    
    public RatePanel(ActionListener listener) {
        this.listener = listener;
        initComponents();
    }

    public double getRate() {
//        double rate;
//        try {
//            rate = Double.parseDouble(tfRate.getText());
//        } catch (NumberFormatException e) {
//            rate = 0.0;
//        }
        double rate = ((Number)tfRate.getValue()).doubleValue();
        return rate;
    }

    public void setRate(double rate) {
        tfRate.setValue(rate);
        //tfRate.setText(String.valueOf(rate));
    }

    private void initComponents() {
        setLayout(new BorderLayout());
        JLabel title = new JLabel("Rate Panel");
        title.setHorizontalAlignment(JLabel.CENTER);
        add( title, BorderLayout.NORTH );
        JPanel panel = new JPanel();
        panel.setLayout( new GridLayout(0,2) );
        panel.add(new JLabel("Dollars in euros: "));
        NumberFormat format = NumberFormat.getNumberInstance();
        format.setMinimumFractionDigits(4);
        format.setMaximumFractionDigits(4);
        tfRate = new JFormattedTextField(format);
        panel.add(tfRate);
        panel.add(new JLabel());
        JButton rateBtn = new JButton("Set rate");
        rateBtn.setActionCommand("set-rate");
        rateBtn.addActionListener(listener);
        add(rateBtn, BorderLayout.SOUTH);
        add(panel, BorderLayout.CENTER);
        //setRate( parent.getModel().getRatioDE() );
    }
    
    
}

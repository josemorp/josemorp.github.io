package cat.proven.currencyconverter;

import cat.proven.currencyconverter.controller.CurrencyConverterController;
import cat.proven.currencyconverter.model.CurrencyConverter;

/**
 *
 * @author ProvenSoft
 */
public class Main {

    public static void main(String[] args) {
        CurrencyConverter model = new CurrencyConverter();
        CurrencyConverterController controller = 
                new CurrencyConverterController(model);
    }
    
}

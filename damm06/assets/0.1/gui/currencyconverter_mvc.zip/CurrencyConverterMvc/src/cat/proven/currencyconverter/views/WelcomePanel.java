package cat.proven.currencyconverter.views;

import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Jose
 */
public class WelcomePanel extends JPanel {

    private final String welcomeMessage;
    
    public WelcomePanel() {
        welcomeMessage = "Welcome to currency converter!";
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());
        JLabel label = new JLabel(welcomeMessage);
        label.setHorizontalAlignment(JLabel.CENTER);
        setBackground(Color.ORANGE);
        label.setForeground(Color.BLACK);
        add(label, BorderLayout.CENTER);
    }
    
}

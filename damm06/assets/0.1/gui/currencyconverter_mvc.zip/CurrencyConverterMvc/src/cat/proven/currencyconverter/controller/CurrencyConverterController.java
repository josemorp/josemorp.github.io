
package cat.proven.currencyconverter.controller;

import cat.proven.currencyconverter.views.MainFrame;
import cat.proven.currencyconverter.model.CurrencyConverter;
import javax.swing.SwingUtilities;


public class CurrencyConverterController {
    private final CurrencyConverter model;
    private MainFrame view;

    public CurrencyConverterController(CurrencyConverter model) {
        this.model = model;
        CurrencyConverterController me = this;
        SwingUtilities.invokeLater(() -> {
            view = new MainFrame(me, model);
        });        
    }

    /**
     * processes actions 
     * @param action to execute.
     */
    public void processRequest(String action) {
        switch (action) {
            case "exit":
                view.exitApp();
                break;
            case "convert-euro-dollar":
                convertEuroDollar();
                break;
            case "convert-dollar-euro":
                convertDollarEuro();
                break;
            case "set-rate":
                setRate();
                break;
            default:
                break;
        }
        
    }
    
    /**
     * performs conversion from euro to dollar.
     */
    public void convertEuroDollar() {
        //double euros = view.getEuroValue();
        double euros = view.getConvertPanel().getEuroValue();
        double dollars = model.euro2dollar(euros);
        //double euros = convertPanel.getEuroValue();
        view.getConvertPanel().setDollarValue(dollars);
    }

    /**
     * performs conversion from dollar to euro.
     */
    public void convertDollarEuro() {
        double dollars = view.getConvertPanel().getDollarValue();
        double euros = model.dollar2euro(dollars);
        view.getConvertPanel().setEuroValue(euros);
    }

    /**
     * stores dollar to euro ratio in model.
     */
    private void setRate() {
        double rate = view.getRatePanel().getRate();
        model.setRatioDE(rate);
    }
    
}

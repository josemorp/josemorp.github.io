package cat.proven.currencyconverter.model;

/**
 * performs convertions between dollars and euros.
 * @author ProvenSoft
 */
public class CurrencyConverter {
    /**
     * the ratio to convert dollar to euro.
     */
    private double ratioDE = 0.87;
    
    public double getRatioDE() {
        return ratioDE;
    }

    public void setRatioDE(double ratioDE) {
        this.ratioDE = ratioDE;
    }
    
    /**
     * converts euro to dollar.
     * @param euros the value in euros to convert to dollars.
     * @return value in dollars.
     */
    public double euro2dollar(double euros) {
        double dollars = euros / ratioDE;
        return dollars;
    }

    /**
     * converts dollar to euro.
     * @param dollars the value in dollars to convert to euros.
     * @return value in euros.
     */
    public double dollar2euro(double dollars) {
        double euros = dollars * ratioDE;
        return euros;
    }
    
}

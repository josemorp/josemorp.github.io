
package cat.proven.currencyconverter;

import cat.proven.currencyconverter.controllers.CurrencyConverterController;
import cat.proven.currencyconverter.views.MainFrame;
import cat.proven.currencyconverter.model.CurrencyConverter;
import javax.swing.SwingUtilities;


public class Main {

    public static void main(String[] args) {
        //instantiate model.
        CurrencyConverter model = new CurrencyConverter();
        //instantiate controller.
        CurrencyConverterController controller = 
                new CurrencyConverterController(model);
        //instantiate view.
        SwingUtilities.invokeLater(() -> {
            MainFrame mainFrame = new MainFrame(controller, model);
            controller.setView(mainFrame);
            mainFrame.setVisible(true);
        });
    }
    
}

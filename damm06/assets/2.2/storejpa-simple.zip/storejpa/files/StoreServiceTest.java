import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class StoreServiceTest {

    private static StoreService storeService;

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        storeService = new StoreService();
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
        storeService.close();
    }

    @Before
    public void setUp() throws Exception {
        // Puedes realizar configuraciones adicionales antes de cada prueba si es necesario
    }

    @Test
    public void testGetAllCategories() {
        List<Category> categories = storeService.getAllCategories();
        assertNotNull(categories);
        assertEquals(3, categories.size()); // Ajusta este valor según la cantidad esperada en tu base de datos
    }

    @Test
    public void testGetCategoryByCode() {
        String code = "C001";
        List<Category> categories = storeService.getCategoryByCode(code);
        assertNotNull(categories);
        assertEquals(1, categories.size());
        assertEquals(code, categories.get(0).getCode());
    }

    @Test
    public void testGetAllProducts() {
        List<Product> products = storeService.getAllProducts();
        assertNotNull(products);
        // Ajusta este valor según la cantidad esperada en tu base de datos
        assertEquals(3, products.size());
    }

    @Test
    public void testGetProductByCode() {
        String code = "P001";
        List<Product> products = storeService.getProductByCode(code);
        assertNotNull(products);
        assertEquals(1, products.size());
        assertEquals(code, products.get(0).getCode());
    }

    @Test
    public void testGetProductsByPrice() {
        double price = 19.99;
        List<Product> products = storeService.getProductsByPrice(price);
        assertNotNull(products);
        // Ajusta este valor según la cantidad esperada en tu base de datos
        assertEquals(1, products.size());
        assertEquals(price, products.get(0).getPrice(), 0.001); // Utilizamos un margen de error pequeño para comparar valores de punto flotante
    }

    // Puedes agregar más métodos de prueba según sea necesario

    // ...
}

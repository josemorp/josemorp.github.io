import javax.persistence.*;

@Entity
@Table(name = "products")
@NamedQueries({
        @NamedQuery(name = "Product.getAllProducts", query = "SELECT p FROM Product p"),
        @NamedQuery(name = "Product.getProductByCode", query = "SELECT p FROM Product p WHERE p.code = :code"),
        @NamedQuery(name = "Product.getProductsByPrice", query = "SELECT p FROM Product p WHERE p.price = :price"),
        @NamedQuery(name = "Product.getProductsByStock", query = "SELECT p FROM Product p WHERE p.stock = :stock"),
        @NamedQuery(name = "Product.getProductsByCategoryId", query = "SELECT p FROM Product p WHERE p.category.id = :categoryId")
})
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(unique = true)
    private String code;

    private double price;

    private double stock;

    @ManyToOne
    @JoinColumn(name = "category_id")
    private Category category;

    // Constructor, getters, setters, y otros métodos según sea necesario

    // ...
}

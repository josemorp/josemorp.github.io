package cat.proven.storejpa.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;

/**
 *
 * @author Jose
 */
@Entity
@Table(name = "categories")
@NamedQueries({
        @NamedQuery(name = "Category.getAllCategories", query = "SELECT c FROM Category c"),
        @NamedQuery(name = "Category.getCategoryByCode", query = "SELECT c FROM Category c WHERE c.code = :code")
})
public class Category implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(unique = true)
    private String code;

    @OneToMany(mappedBy = "category", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Product> products;

    // Constructor, getters, setters, y otros métodos según sea necesario

    // ...
}

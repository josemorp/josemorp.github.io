package cat.proven.storejpa.model;

import cat.proven.storejpa.exceptions.IllegalOrphanException;
import cat.proven.storejpa.exceptions.NonexistentEntityException;
import cat.proven.storejpa.exceptions.PreexistingEntityException;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityNotFoundException;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

/**
 *
 * @author ProvenSoft
 */
public class StoreModel {

    /**
     * EntityManagerFactory to create EntityManager
     */
    private final EntityManagerFactory emFactory;
    /**
     * flag to treat properly cascade restrictions
     */
    private final boolean IS_PRODUCT_CATEGORY_NULLABLE;

    public StoreModel() {
        this.IS_PRODUCT_CATEGORY_NULLABLE = false;
        this.emFactory = Persistence.createEntityManagerFactory("StoreJPAPU");
    }

    /**
     * creates entity manager
     *
     * @return EntityManager
     */
    public EntityManager getEntityManager() {
        return emFactory.createEntityManager();
    }

    /**
     * ======= Category related methods ======
     */
    /**
     * inserts a category
     *
     * @param category the category to insert
     * @return number of categories persisted
     * @throws PreexistingEntityException if category already exists
     */
    public int addCategory(Category category) throws PreexistingEntityException {
        int result = 0;
        if (category.getProducts() == null) {
            category.setProducts(new ArrayList<>());
        }
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();
            //get attached products
            List<Product> attachedProducts = new ArrayList<>();
            //attach category products in persistence context.
            for (Product p : category.getProducts()) {
                //get product instance
                p = em.getReference(p.getClass(), p.getId());
                //add to list of attached products
                attachedProducts.add(p);
            }
            category.setProducts(attachedProducts);
            //persist category
            em.persist(category);
            //change category of related products
            for (Product p : category.getProducts()) {
                //save old value for category
                Category oldCategory = p.getCategory();
                //change product to new category
                p.setCategory(category);
                //merge
                p = em.merge(p);
                if (oldCategory != null) {
                    //remove product from old category
                    oldCategory.getProducts().remove(p);
                    //update old category
                    oldCategory = em.merge(oldCategory);
                }
            }
            em.getTransaction().commit();
            result = 1;
        } catch (Exception ex) {
            if (searchCategoryByCode(category.getCode()) != null) {
                throw new PreexistingEntityException("Category " + category + " already exists.");
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return result;
    }

    /**
     * updates a category
     *
     * @param category the category to update
     * @return number of categories updated
     * @throws NonexistentEntityException if category does not exist
     * @throws IllegalOrphanException
     */
    public int modifyCategory(Category category) throws NonexistentEntityException, IllegalOrphanException {
        int result = 0;
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Category persistentCategory = em.find(Category.class, category.getCode());
            if (persistentCategory != null) {
                //get old list of products
                List<Product> oldProducts = persistentCategory.getProducts();
                //get new list of products
                List<Product> products = category.getProducts();
                //remove old products from category
                List<String> illegalOrphanMessages = null;
                for (Product p : oldProducts) {
                    if (!products.contains(p)) {
                        if (illegalOrphanMessages == null) {
                            illegalOrphanMessages = new ArrayList<>();
                        }
                        illegalOrphanMessages.add("You must retain Product " + p + " since its category field is not nullable.");
                    }
                }
                if (illegalOrphanMessages != null) {
                    throw new IllegalOrphanException(illegalOrphanMessages);
                }
                //add new products to list of products of category
                List<Product> attachedProducts = new ArrayList<>();
                //get instances of products
                for (Product p : products) {
                    p = em.getReference(p.getClass(), p.getId());
                    attachedProducts.add(p);
                }
                products = attachedProducts;
                category.setProducts(products);
                //merge category
                category = em.merge(category);
                //update category in products
                for (Product p : products) {
                    if (!oldProducts.contains(p)) {
                        //assign category to products that are new in the list
                        Category oldCategory = p.getCategory();
                        p.setCategory(category);
                        p = em.merge(p);
                        //remove product from category list where it was previously assigned
                        if (oldCategory != null && !oldCategory.equals(category)) {
                            oldCategory.getProducts().remove(p);
                            oldCategory = em.merge(oldCategory);
                        }
                    }
                }
                em.getTransaction().commit();
                result = 1;
            } else {
                throw new NonexistentEntityException("Category with code " + category.getCode() + " does not exist.");
            }
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return result;
    }

    /**
     * removes a category
     *
     * @param category the category to remove
     * @return number of categories removed
     * @throws NonexistentEntityException if category does not exist
     * @throws IllegalOrphanException if category has orphan entities that
     * cannot be null
     */
    public int removeCategory(Category category) throws NonexistentEntityException, IllegalOrphanException {
        int result = 0;
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            try {
                category = em.getReference(Category.class, category.getCode());
                category.getCode();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("Category with code " + category.getCode() + " does not exist.");
            }
            //ckeck if category has products related to it.
            List<String> illegalOrphanMessages = null; //error messages
            //get list of products of category
            List<Product> products = category.getProducts();
            for (Product p : products) {
                if (IS_PRODUCT_CATEGORY_NULLABLE) { //set category of related products to null
                    p.setCategory(null);
                    em.merge(p);
                } else { //if category of product cannot be null->throw exception
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<>();
                    }
                    illegalOrphanMessages.add("This Category (" + category + ") cannot be destroyed since the Product " + p + " in its products field has a non-nullable category field.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            //remove category
            em.remove(category);
            em.getTransaction().commit();
            result = 1;
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return result;
    }

    /**
     * finds a category by code
     *
     * @param code the code to find
     * @return category found or null if not found
     */
    public Category searchCategoryByCode(String code) {
        EntityManager em = getEntityManager();
        Category category = null;
        try {
            category = em.find(Category.class, code);  //returns null if not found.
        } finally {
            em.close();
        }
        return category;
    }

    /**
     * finds all categories
     *
     * @return list of all categories or null in case of error
     */
    public List<Category> searchAllCategories() {
        EntityManager em = getEntityManager();
        List<Category> categories = null;
        try {
            TypedQuery<Category> query = em.createNamedQuery("Category.findAll",Category.class);
            categories = query.getResultList();
        } finally {
            em.close();
        }
        return categories;
    }
    
    /**
     * Finds all categories with name 
     * @param name to search
     * @return list of categories with name. If no category is found,
     * it returns and empty list.
     */
    public List<Category>searchCategoriesByName (String name){
        List<Category> result= new ArrayList<>();
        EntityManager em = getEntityManager();
        try {
            TypedQuery<Category> query = em.createNamedQuery("Category.findByName", Category.class);
            query.setParameter("name", name);
            result = query.getResultList();
        } finally {
            em.close();
        }
        return result;
    }

    /**
     * fetches products of given category
     *
     * @param c the category to fetch
     */
    public void fetchCategoryProducts(Category c) {
        EntityManager em = getEntityManager();
        String sql = "SELECT p FROM Product p where p.category = :code";
        TypedQuery<Product> query2 = em.createQuery(sql, Product.class);
        query2.setParameter("code", c);
        List<Product> products = query2.getResultList();
        if (products != null) {
            for (Product p : products) {
                p = em.getReference(p.getClass(), p.getId());
            }
            c.setProducts(products);
        }
    }

    /**
     * ======= Product related methods ======
     */
    /**
     * inserts a product
     *
     * @param product the product to insert
     * @return number of products inserted
     * @throws PreexistingEntityException if product already exists
     * @throws EntityNotFoundException if related category does not exist
     */
    public int addProduct(Product product) throws PreexistingEntityException, EntityNotFoundException {
        int result = 0;
        if (product.getCategory() == null) {
            product.setCategory(new Category());
        }
        EntityManager em = getEntityManager();
        try {
            em.getTransaction().begin();
            //get attached category
            Category category = product.getCategory();
            if (category != null) {
                category = em.getReference(category.getClass(), category.getCode());
                product.setCategory(category);
            }
            //update category (add product to their list of products)
            if (category != null) {
                category.getProducts().add(product);
                category = em.merge(category);
            }
            //persist product
            em.persist(product);
            em.getTransaction().commit();
            result = 1;
        } catch (Exception ex) {
            if (searchProductById(product.getId()) != null) {
                throw new PreexistingEntityException("Product " + product + " already exists.");
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return result;
    }

    /**
     * removes a product
     *
     * @param product the product to remove
     * @return numer of products removed
     * @throws NonexistentEntityException if product does not exist
     */
    public int removeProduct(Product product) throws NonexistentEntityException {
        int result = 0;
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            try {
                product = em.getReference(product.getClass(), product.getId());
                product.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("Product with id " + product.getId() + " does not exist.");
            }
            //get category
            Category category = product.getCategory();
            if (category != null) {
                //remove product from list of products of related category
                category.getProducts().remove(product);
                //update category
                category = em.merge(category);
            }
            //remove product
            em.remove(product);
            em.getTransaction().commit();
            result = 1;
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return result;
    }

    /**
     * updates a product
     *
     * @param product the product to update
     * @return number of products updated
     * @throws NonexistentEntityException if product does not exist
     */
    public int modifyProduct(Product product) throws NonexistentEntityException {
        int result = 0;
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            //get product into persistence context
            Product persistentProduct = em.find(Product.class, product.getId());
            if (persistentProduct != null) {
                //get old category
                Category oldCategory = persistentProduct.getCategory();
                //get new category
                Category category = product.getCategory();
                if (category != null) {
                    //get attached category
                    category = em.getReference(category.getClass(), category.getCode());
                    product.setCategory(category);
                }
                //remove product from list of products of old category
                if (oldCategory != null && !oldCategory.equals(category)) {
                    oldCategory.getProducts().remove(product);
                    oldCategory = em.merge(oldCategory);
                }
                //add product to list of product of new category
                if (category != null && !category.equals(oldCategory)) {
                    category.getProducts().add(product);
                    category = em.merge(category);
                }
                //persist product
                em.merge(product);
                em.getTransaction().commit();
                result = 1;
            } else {
                throw new NonexistentEntityException("Product with id " + product.getId() + " does not exist.");
            }
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return result;
    }

    /**
     * finds a product by id
     *
     * @param id the id to find
     * @return product found or null if not found
     */
    public Product searchProductById(Integer id) {
        EntityManager em = getEntityManager();
        Product product = null;
        try {
            product = em.find(Product.class, id);  //returns null if not found.
        } finally {
            em.close();
        }
        return product;
    }

    /**
     * finds all products
     *
     * @return list of all products or null in case of error
     */
    public List<Product> searchAllProducts() {
        EntityManager em = getEntityManager();
        List<Product> products = null;
        try {
            TypedQuery<Product> query = em.createNamedQuery("Product.findAll", Product.class);
            products = query.getResultList();
        } finally {
            em.close();
        }
        return products;
    }

}


package cat.proven.storejpa;

import cat.proven.storejpa.model.Category;
import cat.proven.storejpa.model.Product;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Tester {

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("StoreJPAPU");
        EntityManager em = emf.createEntityManager();
        //
        Category cat1;
        Product prod1;
        //
        em.getTransaction().begin();
        //
//        cat1 = new Category("c10", "c10_desc");
//        prod1 = new Product(0, "c20", "c20_desc", 120.0);
//        prod1.setCategory(cat1);
//        List<Product> pList = new ArrayList<>();
//        pList.add(prod1);
//        cat1.setProducts(pList);
        //
//        em.persist(cat1);
        //
        cat1 = em.find(Category.class, "c10");
        System.out.println(cat1);
        cat1.setName("c10_desc1");
        prod1 = em.find(Product.class, 11);
        prod1.setCategory(em.getReference(Category.class, "c05"));
        em.merge(prod1);
        em.merge(cat1);
        System.out.println(prod1);
        System.out.println(cat1);
        em.getTransaction().commit();
        em.getTransaction().begin();
        em.refresh(cat1);
        System.out.println(prod1);
        System.out.println(cat1);
        //
        em.close();
    }
    
}

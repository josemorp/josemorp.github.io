
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CachedRowSetMain {

    private final String query = "select * from countries";  
    
    public static void main(String[] args) {
        CachedRowSetMain app = new CachedRowSetMain();
        app.run();      
    }

    private void run() {
        try {
            DbConnect.loadDriver();
            //instantiate cached row set
            CountryCachedRowSet helper = new CountryCachedRowSet(query);
            
            System.out.println("Showing first 20 countries");
            helper.getCachedRowSet().setPageSize(20);
            helper.getCachedRowSet().execute();
            //display cachedrowset content.
            displayCachedRowSet(helper);  //--1
            pause();
            //add a new country
            System.out.println("Adding a new country as last row: Wonderland");
            //create a new country object.
            Country country = new Country("Wonderland", "HappyCity", 1000.0, 1000000, 100000.0, 120);
            //insert country
            helper.insertInCachedRowSet(country);
            helper.commitToDatabase();
            //crs.acceptChanges(helper.getConnection(false));
            //display cachedrowset content.
            displayCachedRowSet(helper); //--2
            //update last row.
            helper.lastInPage();
            pause();
            System.out.println("Modifying the country in current row");
            country = new Country("Fakeland", "SucksCity", 500.0, 12000, 11000.0, 50);
            helper.updateInCachedRowSet(country);
            helper.commitToDatabase();
            //crs.acceptChanges(helper.getConnection(false));
            //
            //display cachedrowset content.
            displayCachedRowSet(helper); //--3
            pause();
            //
            System.out.println("Delete last row in page");
            //delete last row.
            helper.lastInPage();
            helper.deleteInCachedRowSet();
            helper.commitToDatabase();
            //crs.acceptChanges(helper.getConnection(false));
            
            //display cachedrowset content.
            displayCachedRowSet(helper); //--4
            
            //browse data.
            browseCachedRowSet(helper);
            
        } catch (SQLException | ClassNotFoundException | InstantiationException | IllegalAccessException ex) {
            Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, ex);
        } 
    }

    /**
     * displays CachedRowSet content
     * @param crs CachedRowSet
     * @throws SQLException 
     */
    private void displayCachedRowSet(CountryCachedRowSet crs) throws SQLException {
        System.out.format("Listing %d countries\n", crs.getCachedRowSet().size());
        System.out.println("Page size: "+crs.getCachedRowSet().getPageSize());
        
        if (crs != null) {
            while (crs.getCachedRowSet().next()) {
                Country c = crs.getCurrentRowCountry();
                System.out.format("Id= %d, Name: %s, Capital: %s\n",
                        c.getId(), c.getName(), c.getCapital());
            }            
        }
    }

    
    /**
     * browses along a CachedRowSet
     * @param crs CachedRowSet to browse
     * @throws SQLException 
     */
    private void browseCachedRowSet(CountryCachedRowSet pcrs) throws SQLException {
        String c;
        if (pcrs != null) {
            pcrs.getCachedRowSet().first();
            do {
                c = moveMenu();
                switch (c) {
                    case "N" -> pcrs.nextInPage();
                    case "P" -> pcrs.previousInPage();
                    case "L" -> pcrs.lastInPage();
                    case "F" -> pcrs.firstInPage();
                }
                Country country = pcrs.getCurrentRowCountry();
                System.out.format("name: %s, capital: %s\n",
                        country.getName(), country.getCapital());   
            } while (!c.equals("Q"));            
        }
    }
    
    /**
     * Pauses execution
     */
    private void pause() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Press any key to continue...");
        sc.nextLine();
    }
    
    /**
     * Displays moveMenu and reads option from user.
     *
     * @return the option selected by user.
     */
    private String moveMenu() {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] options = {"Quit", "Next", "Previous", "Last in page", "First in page"};
        System.out.println("===Move menu===");
        for (String option : options) {
            System.out.println("[" + option.charAt(0) + "]" + " - " + option);
        }
        String op = "Q";
        try {
            op = ((br.readLine()).toUpperCase());
        } catch (IOException ioe) {
        }
        return op;
    }
    
}

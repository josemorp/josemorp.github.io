
//import com.sun.rowset.CachedRowSetImpl;
import javax.sql.rowset.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CountryCachedRowSet {

    private final CachedRowSet crs;

    /**
     * constructor
     *
     * @param username The name a user supplies to a database as part of gaining
     * access
     * @param password The user's database password
     * @param url The JDBC URL for the database to which the user wants to
     * connect
     * @param command query to be executed
     * @throws SQLException
     * @throws ClassNotFoundException
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    public CountryCachedRowSet(String url, String username, String password, String command)
            throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {

        crs = RowSetProvider.newFactory().createCachedRowSet();

        crs.setUsername(username);
        crs.setPassword(password);
        crs.setUrl(url);
        crs.setCommand(command);

//      crs.setPageSize(20);
//        this.execute();
    }

    public CountryCachedRowSet(String command)
            throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {

        crs = RowSetProvider.newFactory().createCachedRowSet();

        crs.setUsername(DbConnect.USER);
        crs.setPassword(DbConnect.PASSWORD);
        crs.setUrl(DbConnect.BD_URL);
        crs.setCommand(command);
//      crs.setPageSize(20);
    }
    
    public CachedRowSet getCachedRowSet() {
        return crs;
    }

    /**
     * creates and returns a connection with the given autocommit option.
     *
     * @param autocommit
     * @return Connection
     * @throws java.sql.SQLException
     */
    public Connection getConnection(boolean autocommit) throws SQLException {
        Connection conn = DriverManager.getConnection(crs.getUrl(), crs.getUsername(), crs.getPassword());
        conn.setAutoCommit(autocommit);
        return conn;
    }

    /**
     * commits cachedrowset changes to database.
     *
     * @return true if successful, false otherwise
     */
    public boolean commitToDatabase() {
        boolean b;
        try ( Connection conn = getConnection(false)) {
            // propagate changes and close connection
            crs.acceptChanges(conn);
            // reload data.
            crs.execute();
            b = true;
        } catch (SQLException se) {
            Logger.getLogger(CountryCachedRowSet.class.getName()).log(Level.SEVERE, null, se);
            b = false;
        } catch (Exception e) {
            Logger.getLogger(CountryCachedRowSet.class.getName()).log(Level.SEVERE, null, e);
            b = false;
        }
        return b;
    }

    /**
     * updates current row with given object to the database using a
     * CachedRowSet
     *
     * @param country to update
     * @throws SQLException
     */
    public void updateInCachedRowSet(Country country) throws SQLException {
        crs.updateString("name", country.getName());
        crs.updateString("capital", country.getCapital());
        crs.updateDouble("surface", country.getSurface());
        crs.updateInt("inhabitants", country.getInhabitants());
        crs.updateDouble("pib", country.getPib());
        crs.updateInt("lifeexpectancy", country.getLifeexpectancy());
        crs.updateRow();
    }

    /**
     * inserts an object to the database through CachedRowSet
     *
     * @param country to insert
     * @throws SQLException
     */
    public void insertInCachedRowSet(Country country) throws SQLException {
        crs.moveToInsertRow();
        crs.updateInt("id", 0);
        crs.updateString("name", country.getName());
        crs.updateString("capital", country.getCapital());
        crs.updateDouble("surface", country.getSurface());
        crs.updateInt("inhabitants", country.getInhabitants());
        crs.updateDouble("pib", country.getPib());
        crs.updateInt("lifeexpectancy", country.getLifeexpectancy());
        crs.insertRow();
        crs.moveToCurrentRow();
    }

    /**
     * deletes current row in CachedRowSet
     *
     * @throws SQLException
     */
    public void deleteInCachedRowSet() throws SQLException {
        crs.deleteRow();
    }

    /**
     * moves cursos forwards
     *
     * @return true if successful, false otherwise
     */
    public boolean nextInPage() {
        boolean b = false;
        try {
            if (crs.isLast()) {
                if (crs.getPageSize() > 0) {
                    if (crs.nextPage()) {

                        crs.beforeFirst();
                        b = crs.next();
                    } else {
                        crs.previousPage();
                        this.lastInPage();
                    }
                }
            } else {
                b = crs.next();
            }
        } catch (SQLException ex) {
            b = false;
            Logger.getLogger(CountryCachedRowSet.class.getName()).log(Level.SEVERE, null, ex);
        }
        return b;
    }

    /**
     * moves cursor backwards
     *
     * @return true if successful, false otherwise
     */
    public boolean previousInPage() {
        boolean b = false;
        try {
            if (crs.isFirst()) {
                if (crs.getPageSize() > 0) {
                    if (crs.previousPage()) {
                        crs.afterLast();
                        b = crs.previous();
                    }
                } else {
                    crs.nextPage();

                    this.firstInPage();
                }
            } else {
                b = crs.previous();
            }
        } catch (SQLException ex) {
            b = false;
            Logger.getLogger(CountryCachedRowSet.class.getName()).log(Level.SEVERE, null, ex);
        }
        return b;
    }

    /**
     * moves cursor to first row
     *
     * @return true if successful, false otherwise
     */
    public boolean firstInPage() {
        boolean b;
        try {
            b = crs.first();
        } catch (SQLException ex) {
            b = false;
            Logger.getLogger(CountryCachedRowSet.class.getName()).log(Level.SEVERE, null, ex);
        }
        return b;
    }

    /**
     * moves cursor to last row
     *
     * @return true if successful, false otherwise
     */
    public boolean lastInPage() {
        boolean b;
        try {
            b = crs.last();
        } catch (SQLException ex) {
            b = false;
            Logger.getLogger(CountryCachedRowSet.class.getName()).log(Level.SEVERE, null, ex);
        }
        return b;
    }

    /**
     * gets a Country object with the data in the current row
     *
     * @return Country or null in case of error.
     */
    public Country getCurrentRowCountry() {
        Country c = null;
        try {
            int id = crs.getInt("id");
            String name = crs.getString("name");
            String capital = crs.getString("capital");
            double surface = crs.getDouble("surface");
            int inhabitants = crs.getInt("inhabitants");
            double pib = crs.getDouble("pib");
            int lifeexpectancy = crs.getInt("lifeexpectancy");
            c = new Country(id, name, capital, surface, inhabitants, pib, lifeexpectancy);
        } catch (SQLException ex) {
            c = null;
            Logger.getLogger(CountryCachedRowSet.class.getName()).log(Level.SEVERE, null, ex);
        }
        return c;
    }

}

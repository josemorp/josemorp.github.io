
    import java.io.File;
    import java.io.FileInputStream;
    import java.io.FileOutputStream;
    import java.io.IOException;
    import java.util.List;
    import java.util.zip.ZipEntry;
    import java.util.zip.ZipInputStream;
    /**
     *
     * 
     */
    public class ReadZip {
        List Files;
        private static final String ZIP_FILE = "docs.zip";
        private static final String TO_PATH = "docs/";
        public static void main(String[] args) {
            ReadZip rz = new ReadZip();
            rz.unZip(ZIP_FILE, TO_PATH);
        }
        public void unZip(String zipFile, String path) {
            byte[] buffer = new byte[1024];
            try {
                File folder = new File(TO_PATH);
                if (!folder.exists()) {
                    folder.mkdir();
                }
                ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile));
                ZipEntry ze = zis.getNextEntry();
                while (ze != null) {
                    String fileName = ze.getName();
                    File aNewFile = new File(path + File.separator + fileName);
                    System.out.println("Unzipped file : " + aNewFile.getAbsoluteFile());
                    new File(aNewFile.getParent()).mkdirs();
                    FileOutputStream fos = new FileOutputStream(aNewFile);
                    int len;
                    while ((len = zis.read(buffer)) > 0) {
                        fos.write(buffer, 0, len);
                    }
                    fos.close();
                    ze = zis.getNextEntry();
                }
                zis.closeEntry();
                zis.close();
                System.out.println("END!");
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }


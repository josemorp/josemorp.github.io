
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;


public class FileChannelWrite {

    public static void main(String[] args) throws IOException {

        // Convert the string to a ByteBuffer.
        String s = "Hello World! ";
        byte data[] = s.getBytes();
        ByteBuffer bb = ByteBuffer.wrap(data);

        try (FileChannel fc = new FileOutputStream("permissions.log").getChannel()) {

            fc.write(bb);
            fc.close();
            System.out.println("Done!");
        } catch (IOException x) {
            System.out.println("Exception thrown: " + x);
        }

    }

}

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.*;
import java.nio.channels.FileChannel;

        
/**
 *
 * @author provenSoft
 */
public class FileTransfer {
    
    private final static String FROM_FILE = "sourceFile";
    private final static String TO_FILE = "destinationFile.txt";
    
    public static void main(String[] args) {
      try{ 
        // Create a channel using the source file 
        FileChannel srcChannel = new FileInputStream(FROM_FILE).getChannel();
        // Create channel using the destinationFile
        FileChannel dstChannel = new FileOutputStream(TO_FILE).getChannel();
       
        // Copy file data from source file to destination file
        dstChannel.transferFrom(srcChannel, 0, srcChannel.size());

        // Close channels
        srcChannel.close();
        dstChannel.close();
         
      } catch (Exception e) {
          System.out.println(e);
      }
        
        
    }
    
    
}


import java.io.Serializable;
import java.util.Objects;

/**
 *
 * @author ROSERSA
 */
public class Phone implements Serializable{
    
    private String type;
    private String prefix;
    private String number;

    public Phone() {
    }

    public Phone(String type, String prefix, String number) {
        this.type = type;
        this.prefix = prefix;
        this.number = number;
    }
    
     public Phone(Phone other) {
        this.type = other.type;
        this.prefix = other.prefix;
        this.number = other.number;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 67 * hash + Objects.hashCode(this.type);
        hash = 67 * hash + Objects.hashCode(this.prefix);
        hash = 67 * hash + Objects.hashCode(this.number);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Phone other = (Phone) obj;
        if (!Objects.equals(this.type, other.type)) {
            return false;
        }
        if (!Objects.equals(this.prefix, other.prefix)) {
            return false;
        }
        if (!Objects.equals(this.number, other.number)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Phone{" + "type=" + type + ", prefix=" + prefix + ", number=" + number + '}';
    }
    
    
}

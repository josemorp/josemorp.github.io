


import java.nio.channels.SocketChannel;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.io.*;

/**
 *
 * @author ROSERSA
 */
public class Client {
    
    private boolean             isConnected;
    private SocketChannel       socketChannel;
    private ObjectOutputStream  oos;
    
    public static void main (String[] args) throws IOException{
          Client client = new Client();
          client.sendObject();
       
    }

    public Client() {
        this.isConnected = false;
     
    }
   
    public void sendObject() throws IOException{
        while (!isConnected){
            socketChannel = createChannel();
            
            isConnected = true;
            
            oos = new ObjectOutputStream(socketChannel.socket().getOutputStream());
            
            Phone phone = new Phone ("M", "34", "606 555 1111" );
            
            oos.writeObject(phone);
            
            oos.close();
        }
    }
    
    
    private SocketChannel createChannel () throws IOException {
       SocketChannel sc = SocketChannel.open();
      
       sc.connect(new InetSocketAddress ("127.0.0.1", 9100));
       
       return sc;
    }  
}

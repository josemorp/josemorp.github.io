
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.net.InetSocketAddress;
import java.io.*;


public class Server {
    
    private SocketChannel socketChannel;
    private ObjectInputStream ois; 
    
    public static void main (String[] args) throws IOException, ClassNotFoundException {
        Server server = new Server();
        server.receiveObject();
    }
    
      
    public void receiveObject () throws IOException, ClassNotFoundException {
        socketChannel = createSocketChannel();
        
        System.out.println("Socket Channel= " + socketChannel.toString()); 
        
        ois = new ObjectInputStream(socketChannel.socket().getInputStream()); 
        
        Phone phone = (Phone) ois.readObject();
        
        System.out.println("ObjectReceived  " + phone.toString());
        
        socketChannel.close();
    }

    private SocketChannel createSocketChannel() throws IOException {
        ServerSocketChannel ssc = ServerSocketChannel.open();
        
        ssc.socket().bind(new InetSocketAddress(9100));
        
        System.out.println("Waiting for client  ");
        
        SocketChannel sc = ssc.accept();
        
        System.out.println("connection established  " + sc.getRemoteAddress());
        
        return sc;
    }
}

package NIOFilesExamples;


import java.io.IOException;
import java.nio.*;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class CreateDirectoryAndFile {

    // Directory Path
    private static String dirPath = "test/subDir/subDir2";
    private static String filePath = "/file.dat";

    public static void main(String[] args) {
        // Get and print out system path separator
        FileSystem fs = FileSystems.getDefault();
        String sep = fs.getSeparator();
        System.out.println("System path separator is "+ sep);
        

        // Check If Directory Already Exists Or Not?
        Path dirPathObj = Paths.get(dirPath);

        boolean dirExists = Files.exists(dirPathObj);

        if (dirExists) {

            System.out.println("Directory Already Exists !");

        } else {

            try {

                // Creating The New Directory Structure
                Files.createDirectories(dirPathObj);

                System.out.println("New Directory Successfully Created!");
                // Once Directory structure in created, create a file with
                // default attributes.
                Path filePathObj = Paths.get(dirPath, filePath);
                Path fileObj = Files.createFile(filePathObj);
                System.out.println("File created!" + fileObj.toString());

            } catch (IOException ioExceptionObj) {

                System.out.println("Problem Occured While Creating The Directory "
                        + "Structure= " + ioExceptionObj.getMessage());

            }

        }

    }
}

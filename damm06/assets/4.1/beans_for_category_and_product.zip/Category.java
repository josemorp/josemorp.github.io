import java.beans.*;
import java.io.Serializable;

public class Category implements Serializable {
    
    private PropertyChangeSupport propertySupport;
    private VetoableChangeSupport vetoableSupport;
    
    private String code;
    private String description;    
    
    public Category() {
        propertySupport = new PropertyChangeSupport(this);
        vetoableSupport = new VetoableChangeSupport(this);
    }

    public Category(String code, String description) {
        propertySupport = new PropertyChangeSupport(this);
        vetoableSupport = new VetoableChangeSupport(this);
        this.code = code;
        this.description = description;
    }
        
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        propertySupport.addPropertyChangeListener(listener);
    }
    
    public void removePropertyChangeListener(PropertyChangeListener listener) {
        propertySupport.removePropertyChangeListener(listener);
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) throws PropertyVetoException {
        String oldValue = this.code;
        vetoableSupport.fireVetoableChange("code", oldValue, this.code);
        this.code = code;
        propertySupport.firePropertyChange("code", oldValue, this.code);
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Category{" + "code=" + code + ", description=" + description + '}';
    }
    
}

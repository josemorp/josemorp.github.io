
package cat.proven.javabeansevents;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.beans.PropertyVetoException;
import java.beans.VetoableChangeListener;
import java.beans.VetoableChangeSupport;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Jose 
 * @param <T> 
 */
public class ModelBean<T> implements Serializable {
    
    private List<T> data;
    private int current;
    
    private final PropertyChangeSupport propertySupport;
    private final VetoableChangeSupport vetoableSupport;
    
    public ModelBean() {
        current = -1;
        data = new ArrayList<>();
        propertySupport = new PropertyChangeSupport(this);
        vetoableSupport = new VetoableChangeSupport(this);
    }

    public List<T> getData() {
        return data;
    }

    public void setData(List<T> data) throws PropertyVetoException {
        List<T> oldValue = this.data;
        vetoableSupport.fireVetoableChange("data", oldValue, data);
        this.data = data;
        propertySupport.firePropertyChange("data", oldValue, this.data);
    }
    
    public T getData(int index) {
        return data.get(index);
    }
    
//    public void setData(int index, T datum) throws PropertyVetoException {
//        T oldValue = data.get(index);
//        String propertyName = String.format("data[%d]", index);
//        vetoableSupport.fireVetoableChange(propertyName, oldValue, datum);
//        data.set(index, datum);
//        propertySupport.firePropertyChange(propertyName, oldValue, datum); 
//    }

    public void setData(int index, T datum) throws PropertyVetoException {
        T oldValue = data.get(index);
        vetoableSupport.fireVetoableChange("data", oldValue, datum);
        data.set(index, datum);
        propertySupport.fireIndexedPropertyChange("data", index, oldValue, datum);
    }    
    
    public int getCurrent() {
        return current;
    }

    public void setCurrent(int current) throws PropertyVetoException {
        int oldValue = this.current;
        vetoableSupport.fireVetoableChange("current", oldValue, current);
        this.current = current;
        propertySupport.firePropertyChange("current", oldValue, this.current);
    }
    
    public boolean addElement(T element) {
        T oldValue = null;
        boolean b = false;
        b = this.data.add(element);
        propertySupport.firePropertyChange("data", oldValue, element);
        return b;
    }
    
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        propertySupport.addPropertyChangeListener(listener);
    }
    
    public void addPropertyChangeListener(String propertyName, PropertyChangeListener listener) {
        propertySupport.addPropertyChangeListener(propertyName, listener);
    }
    
    public void removePropertyChangeListener(PropertyChangeListener listener) {
        propertySupport.removePropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(String propertyName, PropertyChangeListener listener) {
        propertySupport.removePropertyChangeListener(propertyName, listener);
    }
    
    public void addVetoableChangeListener(VetoableChangeListener listener) {
        vetoableSupport.addVetoableChangeListener(listener);
    }

    public void addVetoableChangeListener(String propertyName, VetoableChangeListener listener) {
        vetoableSupport.addVetoableChangeListener(propertyName, listener);
    }

    public void removeVetoableChangeListener(VetoableChangeListener listener) {
        vetoableSupport.removeVetoableChangeListener(listener);
    }

    public void removeVetoableChangeListener(String propertyName, VetoableChangeListener listener) {
        vetoableSupport.removeVetoableChangeListener(propertyName, listener);
    }
    
}

/**
 * XmlPersistence.java
 * Example: persistence of a bean to a xml file.
 * @author Jose Moreno
 * @version 
 */

import java.io.*;
import java.beans.*;

public class XmlPersistence {
	
	public static void main (String args[]) {
		
		// instantiate an object.
		Object object1 = new Person("12345678Z", "Peter", 20);
		// show the object an its type.
		System.out.println("Initial->"+object1.toString());
		System.out.println("Initial->Class:"+object1.getClass().getName());
		try {
			
			// persist object to xml file
			XMLEncoder encoder = new XMLEncoder(
			   new BufferedOutputStream(
			   new FileOutputStream("XmlPersistence.xml")));

			encoder.writeObject(object1);
			encoder.close(); 
			
			// recover object from xml file
			XMLDecoder decoder = new XMLDecoder(
				new BufferedInputStream(
				new FileInputStream("XmlPersistence.xml")));

			Object object2 = decoder.readObject();
			decoder.close();
			
			// show the recovered object an its type.
			System.out.println("Final->"+object2.toString());
			System.out.println("Final->Class:"+object2.getClass().getName());
		
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
	}
}


/**
 * Person.java
 * TAD Person
 * @author Jose
 * @version 
 */
 
 import java.io.Serializable;
 
 public class Person implements Serializable {
	/* fields, attributes, properties */
	private String nif;
	private String name;
	private int age;
	/* constructors */
	/** Person()
	 * full initializer constructor
	 * @param String nif: the nif id of this person
	 * @param String name: the name of this person
	 * @param int age: the age of this person
	 * @return nothing
	 */
	public Person(String nif, String name, int age) {
		this.nif = nif;
		this.name = name;
		this.age = age; 
	}
	/** Person()
	 * constructor without any initialization (default constructor)
	 * @param none
	 * @return nothing
	 */
	public Person() {
		this.nif = "";
		this.name = "";
		this.age = 0; 
	}
	/** Person()
	 * copy constructor
	 * @param Person p: person to copy from
	 * @return nothing
	 */
	public Person(Person p) {
		nif = p.nif;
		name = p.name;
		age = p.age; 
	}
	/* accessors */
	/** getNif()
	 * @param none
	 * @return nif
	 */
	public String getNif() {
		return nif;
	}
	/** setNif()
	 * @param String nif: the nif to set
	 * @return nothing
	 */
	public void setNif(String nif) {
		this.nif = nif;
	}
	/** getName()
	 * @param none
	 * @return name
	 */
	public String getName() {
		return name;
	}
	/** setName()
	 * @param String name: the name to set
	 * @return nothing
	 */
	public void setName(String name) {
		this.name = name;
	}
	/** getAge()
	 * @param none
	 * @return age
	 */
	public int getAge() {
		return age;
	}
	/** setAge()
	 * @param int age: the age to set
	 * @return nothing
	 */
	public void setAge(int age) {
		if ( age >= 0 ) this.age = age;
		else age = 0;
	}
	/* methods */
	
	/** toString()
	 * gives a String representations of this person
	 * @param none
	 * @return a string representation of this person
	 */
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("{Person: nif=");
		sb.append(nif);
		sb.append(";name=");
		sb.append(name);
		sb.append(";age=");
		sb.append(age);
		sb.append("}");
		return sb.toString();
		//return ( "{Person: nif="+nif+";name="+name+";age="+age+"}" );
	}
	/** equals()
	 * compares this person to another one
	 * two persons are equals if their nifs are equals.
	 * @param Person other: the other person to compare to
	 * @return true if they are equals, false otherwise
	 */
	public boolean equals(Person other) {
		return (nif.equals(other.nif));
	}
}

@extends('layout')

@section('content')
<h2>Item page</h2>
@endsection
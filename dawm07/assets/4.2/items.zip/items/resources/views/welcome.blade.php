@extends('layout')
 
@section('topmenu')
    @parent
    <a href="http://www.google.es">Google</a>
@endsection
 
@section('content')
<h2>Welcome to Item manager applicacion</h2>
<p>An applicacion made with Laravel framework</p>
@endsection
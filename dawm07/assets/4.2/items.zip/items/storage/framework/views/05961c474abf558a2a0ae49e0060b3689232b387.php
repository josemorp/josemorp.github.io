<ul>
    <li><a href="/home">Home</a></li>
    <li><a href="/items">Items</a></li>
</ul><?php /**PATH /home/jm/ws/dawbi-m07/uf4/items/resources/views/menubar.blade.php ENDPATH**/ ?>
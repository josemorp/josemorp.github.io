@extends('layout')
 
@section('content')
 
@if(empty($items))
    <p>There are no items!</p>
@else
<ul class="list-group">
    @foreach($items as $item)
        <li class="list-group-item"><a href="/items/{{$item->id}}">{{ $item->title }}</a></li>
    @endforeach
</ul>    
@endif
 
@endsection
<ul>
    <li><a href="/home">Home</a></li>
    <li><a href="/items">Items</a></li>
</ul><?php /**PATH /home/alumne/ws/php/items/resources/views/menubar.blade.php ENDPATH**/ ?>
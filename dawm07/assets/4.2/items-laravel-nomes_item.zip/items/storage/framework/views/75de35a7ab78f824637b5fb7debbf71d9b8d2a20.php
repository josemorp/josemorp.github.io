<?php $__env->startSection('content'); ?>

<?php if(empty($item)): ?>
    <p>No item found!</p>
<?php else: ?>
<form>
    <div>
        <label for="id">Id:</label>
        <input type="text" name="id" value="<?php echo e($item->id); ?>"/>
    </div>
    <div>
        <label for="title">Title:</label>
        <input type="text" name="title" value="<?php echo e($item->title); ?>"/>
    </div>
    <div>
        <label for="content">Content:</label>
        <input type="text" name="content" value="<?php echo e($item->content); ?>"/>
    </div>
</form>    
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumne/ws/php/items/resources/views/item/form.blade.php ENDPATH**/ ?>
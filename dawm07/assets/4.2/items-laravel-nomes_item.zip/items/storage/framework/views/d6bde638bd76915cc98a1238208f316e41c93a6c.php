<?php $__env->startSection('topmenu'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('topmenu'); ?>
    <a href="http://www.google.es">Google</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h2>Welcome to Item manager applicacion</h2>
<p>An applicacion made with Laravel framework</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumne/ws/php/items/resources/views/welcome.blade.php ENDPATH**/ ?>
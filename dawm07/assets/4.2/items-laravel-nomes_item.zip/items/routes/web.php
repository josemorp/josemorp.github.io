<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\ItemController;

Route::get('/', function () {
    return view('welcome');
});
 
Route::get('/home', function () {
    return view('welcome');
});
 
Route::get('/items', function () {
    return view('item.index');
});

Route::get('/items/list', [ItemController::class, 'list']);

Route::get('/items/{item}', [ItemController::class, 'find']);
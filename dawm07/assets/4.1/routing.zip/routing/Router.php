<?php

require_once 'Route.php';

/**
 * Router system to controllers
 *
 * @author Jose
 */
class Router {

    /**
     * @var array the array of routes
     */
    public static array $routes = [];

    /**
     * adds a route
     * @param Route $route the route to add
     */
    public static function addRoute(Route $route) {
        array_push(self::$routes, $route);
    }

    /**
     * finds a route
     * @param Route $route the route to find of false if not found
     */
    public static function findRoute(Route $route): Route|false {
        $result = false;
        //for each route, compare only not-null fields
        foreach (self::$routes as $r) {
            $found = ((!is_null($route->getReqMethod())) ? ($r->getReqMethod() === $route->getReqMethod()) : true);
            $found = $found && ((!is_null($route->getReqPath())) ? ($r->getReqPath() === $route->getReqPath()) : true);
            $found = $found && ((!is_null($route->getReqQuery())) ? ($r->getReqQuery() === $route->getReqQuery()) : true);
            if ($found) {  //if found
                $result = $r;
                break;
            }
        }
        return $result;
    }

}

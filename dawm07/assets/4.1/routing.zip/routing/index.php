<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Routing tests</title>
    </head>
    <body>
        <?php
        require_once 'Router.php';
        function prettyVarDump(mixed $var) {
            echo "<pre>";
            var_dump($var);
            echo "</pre>";
        }
        //prettyVarDump($_SERVER);
        //configure routes
        Router::addRoute(new Route('get', '/test1', '', 'ControllerA', 'func1'));
        Router::addRoute(new Route('get', '/test1', 'a=1&b=2', 'ControllerA', 'func2'));
        Router::addRoute(new Route('get', '/test2', 'a=3&b=4', 'ControllerB', 'func1'));
        prettyVarDump(Router::$routes);
        //get request parameters
        $reqMethod = filter_input(INPUT_SERVER, 'REQUEST_METHOD');
        $reqMethod = strtolower($reqMethod);
        $reqPath = filter_input(INPUT_SERVER, 'PATH_INFO');
        $reqQuery = filter_input(INPUT_SERVER, 'QUERY_STRING');
        //build a route with request parameters
        $routeToSearch = new Route($reqMethod, $reqPath, $reqQuery);
        //prettyVarDump($routeToSearch);
        echo $routeToSearch->__toString();
        //search route
        $reqRoute = Router::findRoute($routeToSearch);
        prettyVarDump($reqRoute);
        echo $reqRoute->__toString();
        ?>
    </body>
</html>

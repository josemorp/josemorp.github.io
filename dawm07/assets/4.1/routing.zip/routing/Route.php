<?php

/**
 * Description of Route
 *
 * @author Jose
 */
class Route {
    
    public function __construct(
            private string $reqMethod, 
            private ?string $reqPath=null, 
            private ?string $reqQuery=null, 
            private ?string $ctrlName=null, 
            private ?string $funcName=null) {

    }
    
    public function getReqMethod(): string {
        return $this->reqMethod;
    }

    public function getReqPath(): ?string {
        return $this->reqPath;
    }

    public function getReqQuery(): ?string {
        return $this->reqQuery;
    }

    public function getCtrlName(): ?string {
        return $this->ctrlName;
    }

    public function getFuncName(): ?string {
        return $this->funcName;
    }

    public function setReqMethod(string $reqMethod): void {
        $this->reqMethod = $reqMethod;
    }

    public function setReqPath(string $reqPath): void {
        $this->reqPath = $reqPath;
    }

    public function setReqQuery(string $reqQuery): void {
        $this->reqQuery = $reqQuery;
    }

    public function setCtrlName(string $ctrlName): void {
        $this->ctrlName = $ctrlName;
    }

    public function setFuncName(string $funcName): void {
        $this->funcName = $funcName;
    }

    public function __toString() {
        return "Route:{".implode(',',(array) $this)."}";
    }

}

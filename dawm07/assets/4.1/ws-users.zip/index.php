<?php
//entry point to webservice with mvc arquitecture.
require_once 'controllers/UserController.php';
$controller = new UserController();
$controller->processRequest();
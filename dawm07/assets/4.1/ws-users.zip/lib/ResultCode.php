<?php

/**
 * result codes for application operations
 *
 * @author Jose
 */
class ResultCode {
    private static array $codes = [
        'ok' => 1,
        'validfail' => -11,
        'dbnoconn' => -101,
        'dbbadquery' => -102,
        'useraddintegrity' => -203,
        'userremovefail' => -204
        //TODO add here other result codes
    ];
    
    public static function getValue(string $key) {
        return static::$codes[$key];
    }
}

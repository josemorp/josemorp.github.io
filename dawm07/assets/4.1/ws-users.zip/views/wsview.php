<?php
//view to return data in json format for webservices
echo json_encode($params, JSON_FORCE_OBJECT);

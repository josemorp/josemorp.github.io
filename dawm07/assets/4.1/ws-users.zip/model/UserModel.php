<?php
require_once 'persist/UserPdoDbDao.php';
require_once 'model/User.php';

/**
 * Description of UserModel
 *
 * @author Jose
 */
class UserModel {
    
    private UserPdoDbDao $dao;
    
    public function __construct() {
        $this->dao = new UserPdoDbDao();
    }

    public function addUser(User $user): int {
        return $this->dao->insert($user);
    }
    
    public function removeUser(User $user): int {
        return $this->dao->delete($user);
    }    
    
    public function modifyUser(User $user): int {
        return $this->dao->update($user);
    }
    
    public function findAllUsers(): array {
        return $this->dao->selectAll();
    }
    
    public function findUserById(int $id): ?User {
        return $this->dao->select(new User($id));
    }
    
}

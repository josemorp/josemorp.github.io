<?php
require_once 'model/UserModel.php';
require_once 'views/View.php';
require_once 'lib/Validator.php';
require_once 'lib/ResultCode.php';

/**
 * Description of UserController
 *
 * @author Jose
 */
class UserController {  
    private View $view;
    private UserModel $model;
    
    private string $req;
    private string $requestMethod;

    public function __construct() {
        //instantiate the view loader.
        $this->view = new View();
        //instantiate the model.
        $this->model = new UserModel();
    }
    
    public function processRequest() {
        $this->req = "";
        //retrieve action command requested by client.
        if (\filter_has_var(\INPUT_POST, 'req')) {
            $this->req = \filter_input(\INPUT_POST, 'req');
        } else {
            if (\filter_has_var(\INPUT_GET, 'req')) {
                $this->req = \filter_input(\INPUT_GET, 'req');
            } else {
                $this->req = "";
            }
        }
        //retrieve request method.
        if (\filter_has_var(\INPUT_SERVER, 'REQUEST_METHOD')) {
            $this->requestMethod = \strtolower(\filter_input(\INPUT_SERVER, 'REQUEST_METHOD'));
        }
        //process action according to request method.
        switch ($this->requestMethod) {
            case 'get':
                $this->doGet();
                break;
            case 'post':
                $this->doPost();
                break;
            default:
                $this->handleError();
                break;
        }        
    }
    
    /**
     * processes get requests from client.
     */
    private function doGet() {
        //process action.
        switch ($this->req) {
            case 'all':
                $this->doSearchAllUsers();
                break;
            case 'id':
                $this->doSearchUserById();
                break;
            default:  //processing default action.
                //$this->handleError();
                break;
        }
    }
    
    private function doPost() {
        //process action.
        switch ($this->req) {
            case 'add':
                $this->doAddUser();
                break;
            case 'remove':
                $this->doRemoveUser();
                break;
            default:  //processing default action.
                //$this->handleError();
                break;
        }        
    }

    private function doSearchAllUsers() {
        $result = $this->model->findAllUsers();
        $this->view->show("wsview.php", ['data' => $result]);
    }

    private function doSearchUserById() {
        $sid = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);
        if (!is_null($sid) && ($sid !== false)) {
            $id = intval($sid);
            $result = $this->model->findUserById($id);
            $this->view->show("wsview.php", ['data' => $result]);            
        }
    }
    
    private function doAddUser() {
        //get user data from form and validate
        $user = Validator::validateUser(INPUT_POST);
        //add user to database
        if (!is_null($user)) {
            $result = $this->model->addUser($user);
            $resultCode = ($result > 0) ? ResultCode::getValue('ok'):ResultCode::getValue('useraddintegrity');
            $this->view->show("wsview.php", ['data' => $user, 'resultCode' => $resultCode]);
        } else {
            $resultCode = ResultCode::getValue('validfail');
            $this->view->show("wsview.php", ['data' => $user, 'resultCode' => $resultCode]);
        }        
    }

    private function doRemoveUser() {
        //get user data from form and validate
        $sid = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
        if (!is_null($sid) && ($sid !== false)) {
            $id = intval($sid);
            $result = $this->model->removeUser(new User($id));
            $resultCode = ($result > 0) ? ResultCode::getValue('ok'):ResultCode::getValue('userremovefail');
            $this->view->show("wsview.php", ['id' => $id, 'resultCode' => $resultCode]);
        }      
    }
    
}

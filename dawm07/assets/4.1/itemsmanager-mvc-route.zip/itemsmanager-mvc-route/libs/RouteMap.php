<?php 
/**
 * routing information.
 */
class RouteMap {
    /**
     * @var array of routes. 
     */
    private $routes;
    /**
     * @var route to be returned when there is no url match. 
     */
    private $defaultRoute;
    
    public function __construct() {
        $this->routes = array(
            array(
                'url' => 'items',
                'controller' => 'ItemController'
            ),
            array(
                'url' => 'find-item',
                'controller' => 'ItemController'
            )
        );
        
        $this->defaultRoute = 'DefaultController';
    }
    
    /**
     * gets the controller corresponding to an url.
     * @param string $url to search
     * @return string controller to route to.
     */
    public function getController($url) {
        foreach ($this->routes as $route) {
            if ($route['url'] === $url) {
                return $route['controller'];
            }
        }
        return $this->defaultRoute;
    }
    
}
?>
<script type="text/javascript">
function submitForm(event) {
    var target = event.target;
    var buttonId = target.id;
    var myForm = document.getElementById('item-form');
    myForm.method.value = buttonId;
    myForm.submit();
    return false;
}
</script>
<?php
   $item = $params['item'];
   $method = $params['method']??"findItem";
   if (is_null($item)) {
       $item = new Item("", "");
   }
   $disable = (($method == "findItem")||($method == "itemForm"))?"disabled":"";
   echo <<<EOT
<form id="item-form" method="get" action="index.php">
    <fieldset>
        <label for="id">Id: </label><input type="text" name="id" id="id" placeholder="enter id" value="{$item->getId()}"/>
        <label for="title">Title: </label><input type="text" name="title" id="title" placeholder="enter title" value="{$item->getTitle()}"/>
        <label for="content">Content: </label><input type="text" name="content" id="content" placeholder="enter content" value="{$item->getContent()}"/>
   </fieldset>
    <fieldset>
        <button type="button" id="findItem" name="findItem" onclick="submitForm(event);return false;">Find</button>
        <button type="button" id="addItem" name="addItem" onclick="submitForm(event);return false;">Add</button>
        <button type="button" id="modifyItem" name="modifyItem" {$disable} onclick="submitForm(event);return false;">Modify</button>
        <button type="button" id="removeItem" name="removeItem" {$disable} onclick="submitForm(event);return false;">Remove</button>
        <input name="ctrl" id="ctrl" hidden="hidden" value="items"/>     
        <input name="method" id="method" hidden="hidden" value="add"/>
    </fieldset>
</form>
EOT;
   
   ?>

<?php
require_once "libs/Context.php";

function configContext() {
        $context = Context::getInstance();
        $context->set('controllersFolder', 'controllers/');
        $context->set('modelsFolder', 'model/');
        $context->set('viewsFolder', 'views/');
        return $context;
}

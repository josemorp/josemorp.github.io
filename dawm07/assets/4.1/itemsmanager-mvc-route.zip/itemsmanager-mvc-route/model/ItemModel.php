<?php
require_once 'Item.php';
require_once 'persist/ItemArrayDao.php';
require_once 'persist/ItemPdoDbDao.php';

/**
 * Service class to provide queries from item data source.
 */
class ItemModel {
    
    private $dataSource;
 
    public function __construct() {
        $this->dataSource = ItemArrayDao::getInstance();
        //$this->dataSource = ItemPdoDbDao::getInstance();
    }

    /**
     * finds all items.
     * @return Item[] list of items or empty array if none found.
     */
    public function searchAll() {
        $items = $this->dataSource->findAllItems();
        return $items;
    }

    /**
     * find an item by id.
     * @param int $id id of item to find.
     * @return Item the found or null if not found.
     */
    public function searchItemById(string $id) {
        $item = $this->dataSource->find(new Item($id));
        return $item;
    }
    
    /**
     * Adds a new item to datasource.
     * @param Item $item : the item to add to the datasource.
     * @return boolean : true is successful, false otherwise.
     */
    public function addItem(Item $item) {
        $numAffected = 0;
        if ($item !== null) {
            $numAffected = $this->dataSource->insert($item);            
        }
        return $numAffected;
    }
    
    /**
     * Modifies an item in datasource.
     * @param Item $item : the item to modify in datasource.
     * @return boolean : true is successful, false otherwise.
     */
    public function modifyItem(Item $item) {
        $numAffected = 0;
        if ($item != null) {
            $numAffected = $this->dataSource->update($item);
        }
        return $numAffected;
    }

    /**
     * Removes an item in datasource.
     * @param Item $item : the item to remove in datasource.
     * @return boolean : true is successful, false otherwise.
     */
    public function removeItem(Item $item) {
        $numAffected = 0;
        if ($item != null) {
            $numAffected = $this->dataSource->delete($item);
        }
        return $numAffected;
    }    
    
}
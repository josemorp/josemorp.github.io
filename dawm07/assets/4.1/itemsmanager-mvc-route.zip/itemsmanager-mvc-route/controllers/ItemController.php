<?php
require_once 'libs/ViewLoader.php';
require_once 'model/ItemModel.php';
require_once 'libs/ItemFormValidation.php';

class ItemController {
    /**
     * @var ViewLoader
     */
    private $view;
    /**
     * @var ItemModel 
     */
    private $model;
    /**
     * @var string  
     */
    private $method;
    
    function __construct() {
        //instantiate the view loader.
        $this->view = new ViewLoader();
        //instantiate the model.
        $this->model = new ItemModel();
        $this->method = "";
        //retrieve action command requested by client.
        if (filter_has_var(INPUT_GET, 'method')) {
            $this->method = filter_input(INPUT_GET, 'method'); 
        }
    }
 
    /**
     * displays home page content.
     */
    public function homePage() {
        $this->view->show("home.php", null);
    }
    
    /**
     * lists all items.
     */
    public function listAll() {
        //get all items.
        $itemList = $this->model->searchAll();
        //pass data to template.
        $data['itemList'] = $itemList;
        //show the template with the given data.
        $this->view->show("list-items.php", $data);
    }    
    
    /**
     * shows a form for an item.
     */
    public function itemForm() {
        $item = ItemFormValidation::getData();
        //pass data to template.
        $data['item'] = $item;
        $data['method'] = $this->method;
        $this->view->show("item-form.php", $data);
    }
    
    /**
     * requests model to add item sent by form.
     */
    public function addItem() {
        $item = ItemFormValidation::getData();
        if ($item === null) {
            printf("<p>Error reading item</p>");
        } else {
            $numAffected = $this->model->addItem($item);
            if ($numAffected>0) {
                printf("<p>Item successfully added</p>");
            } else {
                printf("<p>Error adding item</p>");
            }            
        }
    }

    /**
     * requests model to modify item sent by form.
     */
    public function modifyItem() {
        $item = ItemFormValidation::getData();
        if ($item === null) {
            printf("<p>Error reading item</p>");
        } else {
            $numAffected = $this->model->modifyItem($item);
            if ($numAffected>0) {
                printf("<p>Item successfully modified</p>");
            } else {
                printf("<p>Error modifying item</p>");
            }            
        }
    }

    /**
     * requests model to remove item sent by form.
     */
    public function removeItem() {
        $item = ItemFormValidation::getData();
        if ($item === null) {
            printf("<p>Error reading item</p>");
        } else {
            $numAffected = $this->model->removeItem($item);
            if ($numAffected>0) {
                printf("<p>Item successfully removed</p>");
            } else {
                printf("<p>Error removing item</p>");
            }            
        }
    }

    public function findItem() {
        $item = ItemFormValidation::getData();
        if ($item === null) {
            printf("<p>Error reading item</p>");
        } else {
            $itemFound = $this->model->searchItemById($item->getId());
            if (!is_null($itemFound)) {
                //pass data to template.
                $data['item'] = $itemFound;
                $data['method'] = "change";
                $this->view->show("item-form.php", $data);
            } else {
                printf("<p>Item not found!</p>");
            }            
        }
    }
 
}

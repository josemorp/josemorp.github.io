<?php

class MainController {
    function processRequest() {
        require_once 'configContext.php';
        require_once 'libs/RouteMap.php';
        //get configuration data.
        $config = configContext();
        //instantiate a map to the routing.
        $routeMap = new RouteMap();
        //get request parameters.
        if (filter_has_var(INPUT_GET, 'ctrl')) {
            $controlReq = filter_input(INPUT_GET, 'ctrl'); 
        }
        else {
            $controlReq = "";
        }
        $controllerName = $routeMap->getController($controlReq);
        
        if (filter_has_var(INPUT_GET, 'method')) {
            $methodName = filter_input(INPUT_GET, 'method'); 
        }
        else {
            $methodName = "";
        }
 
        $controllerPath = $config->get('controllersFolder') . $controllerName . '.php';

        //include controller file.
        if (is_file($controllerPath)) {
            require $controllerPath;
        } else {
            die('Error loading controller - 404 not found');
        }

        //if the class or the method do not exist, then show a 404 error.
        if (is_callable(array($controllerName, $methodName)) == false) {
            trigger_error ($controllerName . '->' . $methodName . '` does not exist', E_USER_NOTICE);
            return false;
        }
        //instantiate the controller and invoke the method.
        $controller = new $controllerName();
        $controller->$methodName();
    }
}
?>
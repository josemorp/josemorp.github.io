package cat.proven.store.persist;

import cat.proven.store.model.Product;
import java.util.List;

/**
 *
 * @author ProvenSoft
 */
public class ProductFileObject implements ProductFileInterface {

    @Override
    public int save(String filename, List<Product> products) {
        int counter = 0;
        //TODO
        System.out.println("Saving data to object file");
        return counter;
    }

    @Override
    public List<Product> load(String filename) {
        List<Product> data = null;
        //TODO
        System.out.println("Loading data from object file");
        return data;
    }
    
}

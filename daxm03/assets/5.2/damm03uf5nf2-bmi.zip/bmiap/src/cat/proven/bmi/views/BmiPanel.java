package cat.proven.bmi.views;

import cat.proven.bmi.model.Bmi;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.Locale;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author ProvenSoft
 */
public class BmiPanel extends JPanel implements ActionListener {

    /**
     * the class to provide calculation with data
     */
    private Bmi model;

    /**
     * the text fields that
     */
    private JTextField tfWeight;
    private JTextField tfHeight;
    private JTextField tfBmi;

    /**
     * action and focus listeners
     */
    private final ActionListener actionListener;
    private final FocusListener focusListener;

    /**
     * formatter for data in text fields
     */
    private DecimalFormat formatter;

    public BmiPanel() {
        //instantiate model to perform calculation
        model = new Bmi();
        //set up an action listener: in this case, the panel
        actionListener = this;
        //set up a focus listener to take action when focus is gained, lost, ...
        focusListener = new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                Object sourceObj = e.getSource();
                if (sourceObj instanceof JTextField sourceTf) {
                    sourceTf.setText("");
                }
            }

        };
        //set up a formatter for default locale 
        formatter = (DecimalFormat) DecimalFormat.getNumberInstance(Locale.getDefault());
        formatter.setMaximumFractionDigits(2);
        //set up GUI components
        initComponents();
        //clear form
        doClear();
    }

    /**
     * sets up components in the panel
     */
    private void initComponents() {
        setLayout(new BorderLayout());
        //create header label
        JLabel lbHeader = new JLabel("BMI calculation form");
        lbHeader.setBorder(BorderFactory.createRaisedBevelBorder());
        lbHeader.setHorizontalAlignment(JLabel.CENTER);
        add(lbHeader, BorderLayout.NORTH);
        //create calculation form
        JPanel form = createBmiForm();
        form.setBorder(BorderFactory.createLoweredBevelBorder());
        add(form, BorderLayout.CENTER);
    }

    /**
     * creates BMI calculation form
     *
     * @return panel with calculation form
     */
    private JPanel createBmiForm() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(0, 2));
        //
        panel.add(new JLabel("Weight:"));
        tfWeight = new JTextField(20);
        tfWeight.addFocusListener(focusListener);
        panel.add(tfWeight);
        //
        panel.add(new JLabel("Height:"));
        tfHeight = new JTextField(20);
        tfHeight.addFocusListener(focusListener);
        panel.add(tfHeight);
        //
        JButton btClear = new JButton("Clear");
        btClear.setActionCommand("clear");
        btClear.addActionListener(actionListener);
        panel.add(btClear);
        JButton btCalc = new JButton("Calculate");
        btCalc.setActionCommand("calculate");
        btCalc.addActionListener(actionListener);
        panel.add(btCalc);
        //
        panel.add(new JLabel("Body mass index:"));
        tfBmi = new JTextField(20);
        tfBmi.setEditable(false);
        panel.add(tfBmi);
        //
        return panel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String actionCommand = e.getActionCommand();
        switch (actionCommand) {
            case "clear":
                doClear();
                break;
            case "calculate":
                doCalculate();
                break;
            default:
                break;
        }
    }

    /**
     * clears text fiels and sets to default values
     */
    private void doClear() {
        tfWeight.setText(formatter.format(0.0));
        tfHeight.setText(formatter.format(0.0));
        tfBmi.setText(formatter.format(0.0));
    }

    /**
     * handles calculation action
     */
    private void doCalculate() {
        //read data from form
        String sWeight = tfWeight.getText();
        String sHeight = tfHeight.getText();
        try {
            //parse data
//            double weight = Double.parseDouble(sWeight);
//            double height = Double.parseDouble(sHeight);
            double weight = formatter.parse(sWeight).doubleValue();
            double height = formatter.parse(sHeight).doubleValue();
            //calculate
            double bmi = model.bmiCalc(weight, height);
            //write result to form
            String sBmi = formatter.format(bmi);
            tfBmi.setText(sBmi);
//        } catch (NumberFormatException e) {
//            JOptionPane.showMessageDialog(this, "Invalid data", "Validation", JOptionPane.ERROR_MESSAGE);
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(this, "Invalid data", "Validation", JOptionPane.ERROR_MESSAGE);
        }
    }

}

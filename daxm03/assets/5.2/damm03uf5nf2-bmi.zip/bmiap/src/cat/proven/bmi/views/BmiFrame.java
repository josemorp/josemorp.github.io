package cat.proven.bmi.views;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

/**
 *
 * @author ProvenSoft
 */
public class BmiFrame extends JFrame implements ActionListener {

    private final String title;
    private final String aboutMessage;
    private final ActionListener listener;
    
    private BmiPanel bmiPanel;
    
    public BmiFrame() {
        title = "BMI application";
        aboutMessage = "<html><p>BMI application</p><p>(c) ProvenSoft 2023</p></html>";
        listener = this;
        initComponents();
    }

    private void initComponents() {
        //set window title
        setTitle(title);
        //set default close operation when close button is clicked
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        //add listener to closing window event
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                doExit();
            }
            
        });
        //configure menu bar
        setUpMenu();
        //display bmi panel
        setContentPane(new WelcomePanel());
        //set window size
        setSize(400, 300);
        //set location
        setLocationRelativeTo(null);
    }

    /**
     * sets up menu bar
     */
    private void setUpMenu() {
        JMenuBar menuBar = new JMenuBar();
        JMenu menu;
        JMenuItem menuItem;
        //
        menu = new JMenu("File");
            //
            menuItem = new JMenuItem("Exit");
            menuItem.setActionCommand("exit");
            menuItem.addActionListener(listener);
            menu.add(menuItem);
            //
        menuBar.add(menu);
        //
        menu = new JMenu("Calc");
            //
            menuItem = new JMenuItem("BMI form");
            menuItem.setActionCommand("bmiform");
            menuItem.addActionListener(listener);
            menu.add(menuItem);
            //
        menuBar.add(menu);
        //
        menu = new JMenu("Help");
            //
            menuItem = new JMenuItem("About");
            menuItem.setActionCommand("about");
            menuItem.addActionListener(listener);
            menu.add(menuItem);
            //
        menuBar.add(menu);
        //
        setJMenuBar(menuBar);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        String actionCommand = ae.getActionCommand();
        switch (actionCommand) {
            case "exit":
                doExit();
                break;
            case "about":
                displayAboutDialog();
                break;
            case "bmiform":
                displayBmiPanel();
                break;
            default:
                displayErrorDialog("Error: action not implemented");
                break;
        }
        //System.out.println("Executing action: "+action);
    }

    /**
     * asks for confirmation and exits application
     */
    private void doExit() {
        int answer = JOptionPane.showConfirmDialog(
                this, 
                "Are you sure?", 
                "Exit", 
                JOptionPane.OK_CANCEL_OPTION);
        if (answer == JOptionPane.OK_OPTION) {
            System.exit(0);
        }
    }

    /**
     * displays about dialog
     */
    private void displayAboutDialog() {
        JOptionPane.showMessageDialog(
                this, 
                aboutMessage, 
                "About", 
                JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * displays BMI form panel in content pane
     */
    private void displayBmiPanel() {
        bmiPanel = new BmiPanel();
        setContentPane(bmiPanel);
        validate();
    }

    /**
     * displays a dialog with an error message
     */
    private void displayErrorDialog(String message) {
        JOptionPane.showMessageDialog(
                this, 
                message, 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
    }
    
}

package cat.proven.bmi.model;


/**
 *
 * @author ProvenSoft
 */
public class Bmi {

    /**
     * calculates body mass index corresponding to given weight and height
     * @param weight the weight in kilograms
     * @param height the height in meters
     * @return the value of the body mass index
     */
    public double bmiCalc(double weight, double height) {
        return weight / (height * height);
    }
}

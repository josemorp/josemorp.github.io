package cat.proven.categprods.views;

import cat.proven.categprods.model.Category;
import cat.proven.categprods.model.StoreModel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author ProvenSoft
 */
public class CategoryPanel extends JPanel {

    /**
     * the model to provide data operations
     */
    private final StoreModel model;

    /**
     * the text fields 
     */
    private JTextField tfId;
    private JTextField tfCode;
    private JTextField tfName;

    /**
     * action listener
     */
    private final ActionListener actionListener;

    public CategoryPanel() {
        //instantiate model to perform calculation
        model = new StoreModel();
        //set up an action listener
        actionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String action = e.getActionCommand();
                processAction(action);
            } 
        };
        //set up GUI components
        initComponents();
        //clear data in text fields
        doClear();
    }

    /**
     * sets up components in the panel
     */
    private void initComponents() {
        setLayout(new BorderLayout());
        
        /* === create header label === */
        
        JLabel lbHeader = new JLabel("Category form");
        lbHeader.setBorder(BorderFactory.createRaisedBevelBorder());
        lbHeader.setHorizontalAlignment(JLabel.CENTER);
        add(lbHeader, BorderLayout.NORTH);
        
        /* === create data panel === */
        
        JPanel fieldsPanel = new JPanel();
        fieldsPanel.setLayout(new GridLayout(0, 2));
        //
        fieldsPanel.add(new JLabel("Id:"));
        tfId = new JTextField(20);
        tfId.setEditable(false);
        fieldsPanel.add(tfId);
        //
        fieldsPanel.add(new JLabel("Code:"));
        tfCode = new JTextField(20);
        fieldsPanel.add(tfCode);
        //
        fieldsPanel.add(new JLabel("name:"));
        tfName = new JTextField(20);
        fieldsPanel.add(tfName);
        fieldsPanel.setBorder(BorderFactory.createLoweredBevelBorder());
        add(fieldsPanel, BorderLayout.CENTER);
        
        /* === create button panel === */
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());
        //
        JButton btClear = new JButton("Clear");
        btClear.setActionCommand("clear");
        btClear.addActionListener(actionListener);
        buttonPanel.add(btClear);
        //        
        JButton btSearch = new JButton("Search");
        btSearch.setActionCommand("search");
        btSearch.addActionListener(actionListener);
        buttonPanel.add(btSearch);        
        //
        JButton btAdd = new JButton("Add");
        btAdd.setActionCommand("add");
        btAdd.addActionListener(actionListener);
        buttonPanel.add(btAdd);        
        //
        JButton btModify = new JButton("Modify");
        btModify.setActionCommand("modify");
        btModify.addActionListener(actionListener);
        buttonPanel.add(btModify);         
        //
        JButton btRemove = new JButton("Remove");
        btRemove.setActionCommand("remove");
        btRemove.addActionListener(actionListener);
        buttonPanel.add(btRemove);         
        //
        buttonPanel.setBorder(BorderFactory.createLoweredBevelBorder());
        add(buttonPanel, BorderLayout.SOUTH);
    }

    /**
     * processes actions
     * @param action the action to process
     */
    private void processAction(String action) {
        if (action != null) {
            switch (action) {
                case "clear":
                    doClear();
                    break;
                case "search":
                    doSearch();
                    break;
                case "add":
                    doAdd();
                    break;
                case "modify":
                    doModify();
                    break;
                case "remove":
                    doRemove();
                    break;
                default:
                    displayErrorDialog("Action not implemented");
            }            
        }
    }

    /**
     * clears text fiels and sets to default values
     */
    private void doClear() {
        tfId.setText(String.valueOf(0));
        tfCode.setText("");
        tfName.setText("");
    }

    /**
     * searches category in database given its code and displays result
     */
    private void doSearch() {
        try {
            //read code from field
            String code = tfCode.getText();
            //search category with given code
            Category cat = model.findCategoryByCode(code);
            if (cat != null) {
                toFields(cat);
            } else {
                JOptionPane.showMessageDialog(this, "Category not found", "Result", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (NumberFormatException e) {
            displayErrorDialog("Invalid data");
        } catch (SQLException ex) {
            displayErrorDialog("Error querying database");
        }        
    }
    
    /**
     * adds category with data given by fields to database
     */
    private void doAdd() {
        try {
            //read data from fields
            Category cat = fromFields();
            //validate code
            if (cat.getCode().length() > 3) {  //min. length of code
                //add category to database
                int result = model.addCategory(cat);
                //display result
                String message = (result == 1) ? "Category successfully added" : "Category not added";
                JOptionPane.showMessageDialog(this, message, "Result", JOptionPane.INFORMATION_MESSAGE);
            } else {
                displayErrorDialog("Invalid value for code");
            }
        } catch (NumberFormatException e) {
            displayErrorDialog("Invalid data");
        } catch (SQLException ex) {
            displayErrorDialog("Error querying database");
        }
    }
    
    /**
     * modifies category in database with data in fields
     */
    private void doModify() {
        try {
            //read data from fields
            Category newCat = fromFields();
            long id = newCat.getId();
            if (id != 0) {
                Category currCat = new Category(id);
                //modify category in database
                int result = model.modifyCategory(currCat, newCat);
                //display result
                String message = (result == 1) ? "Category successfully modified" : "Category not modified";
                JOptionPane.showMessageDialog(this, message, "Result", JOptionPane.INFORMATION_MESSAGE);                
            } 
        } catch (NumberFormatException e) {
            displayErrorDialog("Invalid data");
        } catch (SQLException ex) {
            displayErrorDialog("Error querying database");
        }        
    }
    
    /**
     * removes category from database given data in fields
     */
    private void doRemove() {
        try {
            //read data from fields
            Category cat = fromFields();
            long id = cat.getId();
            if (id != 0) {
                //remove category from database
                int result = model.removeCategory(cat);
                //display result
                String message = (result == 1) ? "Category successfully removed" : "Category not removed";
                JOptionPane.showMessageDialog(this, message, "Result", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (NumberFormatException e) {
            displayErrorDialog("Invalid data");
        } catch (SQLException ex) {
            displayErrorDialog("Error querying database");
        }         
    }
    
    /**
     * displays a dialog with an error message
     */
    private void displayErrorDialog(String message) {
        JOptionPane.showMessageDialog(
                this, 
                message, 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
    }   
    
    /**
     * reads data in fields and creates a category with that data
     * @return a category object with data in fields
     * @throws NumberFormatException in case of data conversion error
     */
    private Category fromFields() throws NumberFormatException {
        Category c = null;
        long id = Long.parseLong(tfId.getText());
        String code = tfCode.getText();
        String name = tfName.getText();
        c = new Category(id, code, name);
        return c;
    }
    
    /**
     * writes category data in fields
     * @param cat category object which data has to be written to fields
     */
    private void toFields(Category cat) {
        tfId.setText(String.valueOf(cat.getId()));
        tfCode.setText(String.valueOf(cat.getCode()));
        tfName.setText(String.valueOf(cat.getName()));
    }    
}

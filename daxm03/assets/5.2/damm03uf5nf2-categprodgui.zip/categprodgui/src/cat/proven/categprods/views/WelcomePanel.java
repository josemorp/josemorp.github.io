
package cat.proven.categprods.views;

import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 *
 * @author ProvenSoft
 */
public class WelcomePanel extends JPanel {

    private final String welcomeMessage;

    public WelcomePanel() {
        welcomeMessage = "<html><p>Welcome to Store application</p><p>(c) ProvenSoft 2023</p></html>";
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());
        setBackground(Color.MAGENTA);
        JLabel label = new JLabel(welcomeMessage);
        label.setHorizontalAlignment(SwingConstants.CENTER);
        add(label, BorderLayout.CENTER);
    }
    
}

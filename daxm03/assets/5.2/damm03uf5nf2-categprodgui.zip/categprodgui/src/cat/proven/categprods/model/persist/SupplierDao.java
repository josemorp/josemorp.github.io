package cat.proven.categprods.model.persist;

import cat.proven.categprods.model.Supplier;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ProvenSoft
 */
public class SupplierDao {

    private final DbConnect dbConnect;

    public SupplierDao(DbConnect dbConnect) {
        this.dbConnect = dbConnect;
    }
    private Supplier fromResultSet(ResultSet rs) throws SQLException {
        Supplier obj = null;
        //TODO
        return obj;
    }
    
    public List<Supplier> selectAll() throws SQLException {
        List<Supplier> result = new ArrayList<>();
        //TODO

        return result;
    }    
    
    //TODO
}

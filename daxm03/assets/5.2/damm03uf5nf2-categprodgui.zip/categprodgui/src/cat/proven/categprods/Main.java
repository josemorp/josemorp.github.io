package cat.proven.categprods;

import cat.proven.categprods.model.persist.DbConnect;
import cat.proven.categprods.views.MainFrame;
import javax.swing.SwingUtilities;

/**
 *
 * @author ProvenSoft
 */
public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    DbConnect.loadDriver();
                    MainFrame mainFrame = new MainFrame();
                    mainFrame.setVisible(true);
                } catch (ClassNotFoundException ex) {
                    System.err.println("Database driver not found");
                }
            }
        });
    }
    
}


package cat.proven.categprods.views;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

/**
 *
 * @author ProvenSoft
 */
public class MainFrame extends JFrame {

    /**
     * the window title
     */
    private final String titleText;
    /**
     * the message of about display window
     */
    private final String aboutMessage;
    /**
     * the action listener
     */
    private final ActionListener actionListener;
    /**
     * the category panel to manage categories
     */
    private CategoryPanel categoryPanel;
    
    public MainFrame() {
        titleText = "Store GUI app";
        aboutMessage = "<html><p>Store GUI application</p><p>(c) ProvenSoft 2023</p></html>";
        actionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String action = e.getActionCommand();
                processAction(action);
            } 
        };
        initComponents();
    }

    /**
     * creates components
     */
    private void initComponents() {
        setTitle(titleText);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                doExit();
            }
        });
        createMenuBar();
        setContentPane(new WelcomePanel());
        setLocationRelativeTo(null);
        setSize(400, 300);
    }
    
    /**
     * creates menu bar
     */
    private void createMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        JMenu menu;
        JMenuItem menuItem;
        //
        menu = new JMenu("File");
            //
            menuItem = new JMenuItem("Exit");
            menuItem.setActionCommand("exit");
            menuItem.addActionListener(actionListener);
            menu.add(menuItem);
            //
        menuBar.add(menu);
        //
        menu = new JMenu("Edit");
            //
            menuItem = new JMenuItem("Manage categories");
            menuItem.setActionCommand("catmng");
            menuItem.addActionListener(actionListener);
            menu.add(menuItem);
            //
            menuItem = new JMenuItem("Manage products");
            menuItem.setActionCommand("prodmng");
            menuItem.addActionListener(actionListener);
            menu.add(menuItem);
            //
            menuItem = new JMenuItem("Manage suppliers");
            menuItem.setActionCommand("supmng");
            menuItem.addActionListener(actionListener);
            menu.add(menuItem);
            //
        menuBar.add(menu);
        //
        menu = new JMenu("Help");
            //
            menuItem = new JMenuItem("About");
            menuItem.setActionCommand("about");
            menuItem.addActionListener(actionListener);
            menu.add(menuItem);
            //
        menuBar.add(menu);
        //
        setJMenuBar(menuBar);

    }
    
    /**
     * processes action
     * @param action the action to process
     */
    private void processAction(String action) {
        if (action != null) {
            switch (action) {
                case "exit":
                    doExit();
                    break;
                case "about":
                    displayAboutDialog();
                    break;
                case "catmng":
                    displayCategoryPanel();
                    break;
                default:
                    displayErrorDialog("Error: action not implemented");
                    break;
            }            
        }
    }
    
    /**
     * handles exit application
     */
    private void doExit() {
        int answer = JOptionPane.showConfirmDialog(
                this, 
                "Are you sure?", 
                "Exit", 
                JOptionPane.OK_CANCEL_OPTION);
        if (answer == JOptionPane.OK_OPTION) {
            System.exit(0);
        }
    }

    /**
     * displays about dialog
     */
    private void displayAboutDialog() {
        JOptionPane.showMessageDialog(
                this, 
                aboutMessage, 
                "About", 
                JOptionPane.INFORMATION_MESSAGE);
    }    
    
    /**
     * displays a dialog with an error message
     */
    private void displayErrorDialog(String message) {
        JOptionPane.showMessageDialog(
                this, 
                message, 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
    }

    /**
     * displays category panel in content pane
     */
    private void displayCategoryPanel() {
        categoryPanel = new CategoryPanel();
        setContentPane(categoryPanel);
        validate();
    }
    
}
